# Supplementary media budget

Videos are first-class supplementary artifacts. Contact sheets support the PDF
appendix but do not replace the corresponding video evidence.

## Current allocation

- 12 reviewed dual-view simulation MP4 clips: approximately 3.65 MiB total.
- 120 complete-coverage agent-view MP4 clips: approximately 25.01 MiB total.
- All simulation videos: 132 clips, approximately 28.64 MiB total.
- 96 agent-view stills: approximately 1.07 MiB total.
- 12 appendix contact sheets: approximately 1.12 MiB total.
- Current double-blind release: approximately 31.65 MiB uncompressed and 30.64
  MiB as a ZIP, leaving approximately 68.35 MiB under the stricter uncompressed
  limit for later real-robot media.
- Submission ceiling: 100 MiB. The release builder enforces the stricter
  uncompressed-directory limit as well as allowing the final ZIP to be checked.

The 12 representative simulation clips are H.264, 512x256, YUV 4:2:0, and 20
fps. The 120 complete-coverage clips use the released 256x256 agent view. They
are copied without re-encoding because both source sets are already compact.

## Real-robot video policy

Keep lossless or camera-native masters outside the submission bundle and record
their hashes. Add publication copies to the release using this order:

1. Preserve the source resolution and meaningful temporal detail. Encode H.264
   with YUV 4:2:0 and CRF 20-21; omit unused audio.
2. If the complete bundle approaches 90 MiB, raise CRF to 22-23 for the largest
   real-robot clips first. Do not re-encode the already compact simulation clips.
3. If it still exceeds the budget, cap real-robot video at 720p while preserving
   aspect ratio. Never upscale a lower-resolution source.
4. Reduce frame rate only as a final step, and never below the rate needed to
   show object motion and asynchronous robot response faithfully.

After any media addition, run:

```bash
python scripts/audit_media_budget.py
python scripts/build_release.py
```

The audit reports every MP4's codec, dimensions, frame rate, duration, and size;
the release builder rejects a package over 100 MiB.
