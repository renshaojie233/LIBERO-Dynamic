# Representative task gallery

This gallery is a compact, appendix-ready view of the 40-task benchmark. It
contains one task from each canonical ten-task subset and one reviewed clip for
each of the three motion families, all at 0.09 m/s:

| Subset | Selected task | Why it is representative |
| --- | --- | --- |
| Spatial | Black bowl between plate and ramekin -> plate | Tests spatial language and distractor disambiguation. |
| Object | Tomato sauce -> basket | Tests object identity among visually similar packaged objects. |
| Goal | Bowl -> stove | Tests goal-conditioned placement in a kitchen scene. |
| Long-horizon | Both moka pots -> stove | Tests two-object, sequential composition. |

The 12 clips are measured data from the reviewed benchmark release, not newly
simulated illustrations. The MP4 files are primary electronic-supplement
artifacts and must remain in the release. Each MP4 preserves the released dual
view. For PDF layout, `frames/` contains eight uniformly spaced agent-view
frames per clip, and `contact_sheets/` contains one 4x2 JPEG strip per clip. The
stills omit the wrist-camera half only to improve legibility at appendix scale.

`selection.json` records task IDs, language instructions, motion family,
trajectory index, phase, speed, source filename, and the source SHA-256. The
selection is independent of any model's success or failure. Different reviewed
trajectory indices and phases are retained because this is a task/motion gallery,
not a controlled model comparison.

Rebuild and validate the stills with FFmpeg and FFprobe:

```bash
python task_gallery/scripts/build_task_gallery.py
```

The script requires exactly 4 tasks, 3 motion families per task, 12 videos, 96
stills, and 12 contact sheets. It writes `gallery_manifest.json` and fails on a
source checksum mismatch.

Recommended appendix organization: one row per selected task and three columns
for Linear, Curvilinear, and Zigzag. Use the contact sheets in the main appendix;
keep the individual frames and short MP4s in the supplementary directory.

For full task coverage, `full_video_gallery/` contains all 40 tasks under all
three motion families at the same 0.09 m/s speed. See
`FULL_VIDEO_GALLERY_README.md` for its deterministic selection and concise file
naming contract.

The current clips are H.264, 512x256, 20 fps, and total approximately 3.65 MiB.
They are already compact and should not be transcoded again. See
`MEDIA_BUDGET.md` for the policy used when real-robot videos are added.
