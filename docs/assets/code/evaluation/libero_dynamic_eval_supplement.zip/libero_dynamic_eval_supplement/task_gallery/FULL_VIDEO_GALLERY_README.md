# Full 40-task video gallery

`full_video_gallery/` contains one third-person video for every combination of
the 40 benchmark tasks and three motion families at 0.09 m/s: 120 videos total.
It complements the smaller 12-clip dual-view representative gallery.

The filename format is:

```text
T<global task ID>_<subset>_<short task label>__<motion>__009mps.mp4
```

For example:

```text
T31_spatial_bowl_between__linear__009mps.mp4
```

The task, motion family, and speed are therefore visible without opening the
manifest. Motion names are written in full: `linear`, `curvilinear`, and
`zigzag`.

Selection is deterministic and independent of model results. For every
task/motion cell, the builder accepts only formal-release rows with `status=ok`,
no error, strict physical success, and `diagnostics.ok=true`. It then selects
the minimum available trajectory index and the successful phase closest to 0.5,
with lexical item ID as the final tie-break. `manifest.json` records the exact
source item, checks, trajectory, phase, dimensions, duration, and SHA-256.

Only the 256x256 `agentview_rgb` stream is included in the full gallery to keep
all 120 clips readable and leave capacity for real-robot videos. The 12 primary
examples under `videos/` retain the released dual view.

The private release location is intentionally not stored. An authorized author
can rebuild the gallery by supplying it at runtime:

```bash
python task_gallery/scripts/build_full_video_gallery.py \
  --source-root '<rclone release root ending at raw>'
```
