#!/usr/bin/env python3
"""Extract and audit appendix-ready frames from the reviewed task clips."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess


GALLERY = Path(__file__).resolve().parents[1]
SELECTION = GALLERY / "selection.json"
FRAME_COUNT = 8


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def run(command: list[str]) -> str:
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    return result.stdout.strip()


def probe(path: Path) -> dict[str, object]:
    raw = run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=width,height,avg_frame_rate,nb_frames:format=duration,size",
            "-of",
            "json",
            str(path),
        ]
    )
    return json.loads(raw)


def build_clip(task: dict[str, object], clip: dict[str, object]) -> dict[str, object]:
    video = GALLERY / str(clip["video"])
    if not video.is_file():
        raise FileNotFoundError(video)
    actual_hash = sha256(video)
    if actual_hash != clip["source_sha256"]:
        raise RuntimeError(f"Checksum mismatch for {video.name}")

    metadata = probe(video)
    stream = metadata["streams"][0]
    duration = float(metadata["format"]["duration"])
    if int(stream["width"]) != 512 or int(stream["height"]) != 256:
        raise RuntimeError(f"Unexpected dual-view dimensions for {video.name}: {stream}")

    stem = video.stem
    frame_dir = GALLERY / "frames" / stem
    if frame_dir.exists():
        shutil.rmtree(frame_dir)
    frame_dir.mkdir(parents=True)
    frame_rate = FRAME_COUNT / duration
    frame_pattern = frame_dir / "frame_%02d.jpg"
    run(
        [
            "ffmpeg",
            "-loglevel",
            "error",
            "-y",
            "-i",
            str(video),
            "-vf",
            f"fps={frame_rate:.12f},crop=iw/2:ih:0:0,scale=256:256:flags=lanczos",
            "-frames:v",
            str(FRAME_COUNT),
            "-q:v",
            "3",
            str(frame_pattern),
        ]
    )
    frames = sorted(frame_dir.glob("frame_*.jpg"))
    if len(frames) != FRAME_COUNT:
        raise RuntimeError(f"Expected {FRAME_COUNT} frames for {video.name}, found {len(frames)}")

    contact = GALLERY / "contact_sheets" / f"{stem}.jpg"
    contact.parent.mkdir(parents=True, exist_ok=True)
    run(
        [
            "ffmpeg",
            "-loglevel",
            "error",
            "-y",
            "-framerate",
            "1",
            "-start_number",
            "1",
            "-i",
            str(frame_pattern),
            "-vf",
            "tile=4x2:padding=4:margin=4:color=white",
            "-frames:v",
            "1",
            "-q:v",
            "2",
            str(contact),
        ]
    )
    return {
        "subset": task["subset"],
        "suite": task["suite"],
        "task_id_zero_based": task["task_id_zero_based"],
        "language": task["language"],
        "level": clip["level"],
        "motion": clip["motion"],
        "speed_mps": 0.09,
        "trajectory_index": clip["trajectory_index"],
        "phase_ratio": clip["phase_ratio"],
        "video": str(video.relative_to(GALLERY)),
        "video_sha256": actual_hash,
        "duration_seconds": duration,
        "source_frame_count": int(stream["nb_frames"]),
        "frames": [
            {
                "file": str(frame.relative_to(GALLERY)),
                "sha256": sha256(frame),
            }
            for frame in frames
        ],
        "contact_sheet": str(contact.relative_to(GALLERY)),
        "contact_sheet_sha256": sha256(contact),
    }


def main() -> int:
    for executable in ("ffmpeg", "ffprobe"):
        if shutil.which(executable) is None:
            raise RuntimeError(f"Required executable not found: {executable}")
    selection = json.loads(SELECTION.read_text(encoding="utf-8"))
    tasks = selection["tasks"]
    if len(tasks) != 4:
        raise AssertionError("The gallery must contain exactly four task subsets")
    rows = []
    for task in tasks:
        clips = task["clips"]
        if {clip["level"] for clip in clips} != {"l1", "l2", "l3"}:
            raise AssertionError(f"Incomplete motion-family coverage: {task['subset']}")
        rows.extend(build_clip(task, clip) for clip in clips)
    if len(rows) != 12 or sum(len(row["frames"]) for row in rows) != 96:
        raise AssertionError("Gallery cardinality must be 12 clips and 96 stills")
    manifest = {
        "schema": "libero_dynamic_representative_gallery_manifest_v1",
        "selection_sha256": sha256(SELECTION),
        "clip_count": len(rows),
        "still_count": sum(len(row["frames"]) for row in rows),
        "contact_sheet_count": len(rows),
        "clips": rows,
    }
    output = GALLERY / "gallery_manifest.json"
    output.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
