#!/usr/bin/env python3
"""Build a 40-task x 3-motion video gallery from strict release manifests."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
from typing import Any


GALLERY = Path(__file__).resolve().parents[1]
MOTIONS = {"l1": "linear", "l2": "curvilinear", "l3": "zigzag"}
SPEED_MPS = 0.09

# global ID, suite, zero-based suite task ID, exact release-directory task name,
# concise public filename label
TASKS = [
    (1, "libero_10", 0, "LIVING_ROOM_SCENE2_put_both_the_alphabet_soup_and_the_tomato_sauce_in_the_basket", "soup_tomato_basket"),
    (2, "libero_10", 1, "LIVING_ROOM_SCENE2_put_both_the_cream_cheese_box_and_the_butter_in_the_basket", "cheese_butter_basket"),
    (3, "libero_10", 2, "KITCHEN_SCENE3_turn_on_the_stove_and_put_the_moka_pot_on_it", "stove_moka"),
    (4, "libero_10", 3, "KITCHEN_SCENE4_put_the_black_bowl_in_the_bottom_drawer_of_the_cabinet_and_close_it", "bowl_bottom_drawer"),
    (5, "libero_10", 4, "LIVING_ROOM_SCENE5_put_the_white_mug_on_the_left_plate_and_put_the_yellow_and_white_mug_on_the_right_plate", "two_mugs_plates"),
    (6, "libero_10", 5, "STUDY_SCENE1_pick_up_the_book_and_place_it_in_the_back_compartment_of_the_caddy", "book_caddy"),
    (7, "libero_10", 6, "LIVING_ROOM_SCENE6_put_the_white_mug_on_the_plate_and_put_the_chocolate_pudding_to_the_right_of_the_plate", "mug_pudding"),
    (8, "libero_10", 7, "LIVING_ROOM_SCENE1_put_both_the_alphabet_soup_and_the_cream_cheese_box_in_the_basket", "soup_cheese_basket"),
    (9, "libero_10", 8, "KITCHEN_SCENE8_put_both_moka_pots_on_the_stove", "two_moka_stove"),
    (10, "libero_10", 9, "KITCHEN_SCENE6_put_the_yellow_and_white_mug_in_the_microwave_and_close_it", "mug_microwave"),
    (11, "libero_goal", 0, "open_the_middle_drawer_of_the_cabinet", "open_middle_drawer"),
    (12, "libero_goal", 1, "put_the_bowl_on_the_stove", "bowl_stove"),
    (13, "libero_goal", 2, "put_the_wine_bottle_on_top_of_the_cabinet", "wine_cabinet"),
    (14, "libero_goal", 3, "open_the_top_drawer_and_put_the_bowl_inside", "bowl_top_drawer"),
    (15, "libero_goal", 4, "put_the_bowl_on_top_of_the_cabinet", "bowl_cabinet"),
    (16, "libero_goal", 5, "push_the_plate_to_the_front_of_the_stove", "plate_front_stove"),
    (17, "libero_goal", 6, "put_the_cream_cheese_in_the_bowl", "cheese_bowl"),
    (18, "libero_goal", 7, "turn_on_the_stove", "turn_on_stove"),
    (19, "libero_goal", 8, "put_the_bowl_on_the_plate", "bowl_plate"),
    (20, "libero_goal", 9, "put_the_wine_bottle_on_the_rack", "wine_rack"),
    (21, "libero_object", 0, "pick_up_the_alphabet_soup_and_place_it_in_the_basket", "soup_basket"),
    (22, "libero_object", 1, "pick_up_the_cream_cheese_and_place_it_in_the_basket", "cheese_basket"),
    (23, "libero_object", 2, "pick_up_the_salad_dressing_and_place_it_in_the_basket", "dressing_basket"),
    (24, "libero_object", 3, "pick_up_the_bbq_sauce_and_place_it_in_the_basket", "bbq_basket"),
    (25, "libero_object", 4, "pick_up_the_ketchup_and_place_it_in_the_basket", "ketchup_basket"),
    (26, "libero_object", 5, "pick_up_the_tomato_sauce_and_place_it_in_the_basket", "tomato_basket"),
    (27, "libero_object", 6, "pick_up_the_butter_and_place_it_in_the_basket", "butter_basket"),
    (28, "libero_object", 7, "pick_up_the_milk_and_place_it_in_the_basket", "milk_basket"),
    (29, "libero_object", 8, "pick_up_the_chocolate_pudding_and_place_it_in_the_basket", "pudding_basket"),
    (30, "libero_object", 9, "pick_up_the_orange_juice_and_place_it_in_the_basket", "juice_basket"),
    (31, "libero_spatial", 0, "pick_up_the_black_bowl_between_the_plate_and_the_ramekin_and_place_it_on_the_plate", "bowl_between"),
    (32, "libero_spatial", 1, "pick_up_the_black_bowl_next_to_the_ramekin_and_place_it_on_the_plate", "bowl_next_ramekin"),
    (33, "libero_spatial", 2, "pick_up_the_black_bowl_from_table_center_and_place_it_on_the_plate", "bowl_center"),
    (34, "libero_spatial", 3, "pick_up_the_black_bowl_on_the_cookie_box_and_place_it_on_the_plate", "bowl_cookie_box"),
    (35, "libero_spatial", 4, "pick_up_the_black_bowl_in_the_top_drawer_of_the_wooden_cabinet_and_place_it_on_the_plate", "bowl_top_drawer"),
    (36, "libero_spatial", 5, "pick_up_the_black_bowl_on_the_ramekin_and_place_it_on_the_plate", "bowl_ramekin"),
    (37, "libero_spatial", 6, "pick_up_the_black_bowl_next_to_the_cookie_box_and_place_it_on_the_plate", "bowl_next_cookie"),
    (38, "libero_spatial", 7, "pick_up_the_black_bowl_on_the_stove_and_place_it_on_the_plate", "bowl_stove"),
    (39, "libero_spatial", 8, "pick_up_the_black_bowl_next_to_the_plate_and_place_it_on_the_plate", "bowl_next_plate"),
    (40, "libero_spatial", 9, "pick_up_the_black_bowl_on_the_wooden_cabinet_and_place_it_on_the_plate", "bowl_cabinet"),
]


def run(command: list[str]) -> str:
    result = subprocess.run(command, check=True, capture_output=True, text=True)
    return result.stdout


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def remote_join(root: str, *parts: str) -> str:
    return root.rstrip("/") + "/" + "/".join(part.strip("/") for part in parts)


def strict_row(row: dict[str, Any]) -> bool:
    augmentation = ((row.get("dynamic_config") or {}).get("augmentation") or {})
    diagnostics = row.get("diagnostics") or {}
    return (
        row.get("status") == "ok"
        and row.get("error") is None
        and bool(row.get("strict_physical_success"))
        and bool(diagnostics.get("ok"))
        and abs(float(augmentation.get("dynamic_speed_mps", -1.0)) - SPEED_MPS) < 1e-9
    )


def phase_ratio(row: dict[str, Any]) -> float:
    augmentation = ((row.get("dynamic_config") or {}).get("augmentation") or {})
    return float(augmentation.get("phase_offset_ratio", 0.0) or 0.0)


def select_rows(manifest_text: str, task: tuple[int, str, int, str, str]) -> list[dict[str, Any]]:
    global_id, suite, task_id, _release_name, _slug = task
    rows = [json.loads(line) for line in manifest_text.splitlines() if line.strip()]
    selected = []
    for level in MOTIONS:
        candidates = [
            row
            for row in rows
            if strict_row(row)
            and row.get("suite") == suite
            and int(row.get("task_id", -1)) == task_id
            and row.get("level") == level
        ]
        if not candidates:
            raise RuntimeError(f"No strict candidate for T{global_id:02d} {level}")
        minimum_traj = min(int(row["traj_index"]) for row in candidates)
        candidates = [row for row in candidates if int(row["traj_index"]) == minimum_traj]
        selected.append(
            min(candidates, key=lambda row: (abs(phase_ratio(row) - 0.5), row["item_id"]))
        )
    return selected


def probe(path: Path) -> dict[str, Any]:
    return json.loads(
        run(
            [
                "ffprobe",
                "-v",
                "error",
                "-select_streams",
                "v:0",
                "-show_entries",
                "stream=codec_name,pix_fmt,width,height,r_frame_rate,nb_frames:format=duration,size",
                "-of",
                "json",
                str(path),
            ]
        )
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-root", required=True, help="rclone release root ending at raw/")
    parser.add_argument("--output-root", type=Path, default=GALLERY / "full_video_gallery")
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    for executable in ("rclone", "ffprobe"):
        if shutil.which(executable) is None:
            raise RuntimeError(f"Required executable not found: {executable}")

    output = args.output_root.expanduser().resolve()
    videos = output / "videos"
    videos.mkdir(parents=True, exist_ok=True)
    jobs = []
    task_metadata: dict[int, tuple[tuple[int, str, int, str, str], str]] = {}
    for task in TASKS:
        global_id, _suite, _task_id, release_name, _slug = task
        task_dir = f"task{global_id:02d}__{release_name}"
        manifest_remote = remote_join(
            args.source_root, task_dir, "speed_0.09", "audit", "manifest.jsonl"
        )
        task_metadata[global_id] = (task, task_dir)
        jobs.append((task, task_dir, manifest_remote))

    selections = []
    with ThreadPoolExecutor(max_workers=min(args.workers, 12)) as pool:
        futures = {
            pool.submit(run, ["rclone", "cat", manifest_remote]): (task, task_dir)
            for task, task_dir, manifest_remote in jobs
        }
        for future in as_completed(futures):
            task, task_dir = futures[future]
            for row in select_rows(future.result(), task):
                selections.append((task, task_dir, row))

    downloads = []
    for task, task_dir, row in sorted(selections, key=lambda item: (item[0][0], item[2]["level"])):
        global_id, suite, task_id, _release_name, slug = task
        level = row["level"]
        motion = MOTIONS[level]
        suite_label = "libero10" if suite == "libero_10" else suite.removeprefix("libero_")
        filename = f"T{global_id:02d}_{suite_label}_{slug}__{motion}__009mps.mp4"
        local = videos / filename
        remote = remote_join(
            args.source_root,
            task_dir,
            "speed_0.09",
            "videos",
            "agentview_rgb",
            f"{row['item_id']}.mp4",
        )
        downloads.append((remote, local, task, row, motion))

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as pool:
        futures = {
            pool.submit(run, ["rclone", "copyto", remote, str(local)]): (local, task, row, motion)
            for remote, local, task, row, motion in downloads
        }
        for future in as_completed(futures):
            future.result()

    entries = []
    for _remote, local, task, row, motion in downloads:
        global_id, suite, task_id, release_name, slug = task
        metadata = probe(local)
        stream = metadata["streams"][0]
        if int(stream["width"]) != 256 or int(stream["height"]) != 256:
            raise RuntimeError(f"Unexpected dimensions for {local.name}: {stream}")
        entries.append(
            {
                "global_task_id_one_based": global_id,
                "suite": suite,
                "task_id_zero_based": task_id,
                "task": release_name,
                "short_label": slug,
                "level": row["level"],
                "motion": motion,
                "speed_mps": SPEED_MPS,
                "trajectory_index": int(row["traj_index"]),
                "phase_ratio": phase_ratio(row),
                "source_item_id": row["item_id"],
                "selection_checks": {
                    "status_ok": row["status"] == "ok",
                    "errors_zero": row.get("error") is None,
                    "strict_physical_success": bool(row["strict_physical_success"]),
                    "diagnostics_ok": bool(row["diagnostics"]["ok"]),
                },
                "file": f"videos/{local.name}",
                "sha256": sha256(local),
                "size_bytes": local.stat().st_size,
                "codec": stream["codec_name"],
                "pixel_format": stream["pix_fmt"],
                "width": int(stream["width"]),
                "height": int(stream["height"]),
                "frame_rate": stream["r_frame_rate"],
                "frame_count": int(stream["nb_frames"]),
                "duration_seconds": float(metadata["format"]["duration"]),
            }
        )

    if len(entries) != 120 or len({entry["file"] for entry in entries}) != 120:
        raise AssertionError("Full gallery must contain 120 unique videos")
    for global_id in range(1, 41):
        rows = [entry for entry in entries if entry["global_task_id_one_based"] == global_id]
        if {row["motion"] for row in rows} != set(MOTIONS.values()):
            raise AssertionError(f"Incomplete motion coverage for T{global_id:02d}")
    manifest = {
        "schema": "libero_dynamic_full_video_gallery_v1",
        "selection_rule": "Strict successful row; minimum available trajectory index; phase ratio closest to 0.5; lexical item ID tie-break.",
        "view": "agentview_rgb",
        "speed_mps": SPEED_MPS,
        "task_count": 40,
        "motion_count_per_task": 3,
        "video_count": len(entries),
        "total_video_bytes": sum(entry["size_bytes"] for entry in entries),
        "videos": sorted(entries, key=lambda row: (row["global_task_id_one_based"], row["level"])),
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print(output / "manifest.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
