# Appendix captions

Use one row per subset and three columns in the fixed order Linear,
Curvilinear, and Zigzag. All examples use an object speed of 0.09 m/s; each
cell contains eight uniformly sampled third-person frames.

1. **Spatial.** Pick up the black bowl between the plate and the ramekin and
   place it on the plate. This task tests spatial-relation grounding in the
   presence of nearby distractors.
2. **Object.** Pick up the tomato sauce and place it in the basket. This task
   tests category-level object selection among visually similar containers.
3. **Goal.** Put the bowl on the stove. This task tests goal-conditioned
   placement while the manipulated object moves.
4. **Long-horizon.** Put both moka pots on the stove. This task tests sequential
   two-object composition.

The panels show successful data trajectories rather than policy-comparison
outcomes. Trajectory index and initial phase differ across motion families and
are disclosed in `selection.json`; no model result was used to choose them.
