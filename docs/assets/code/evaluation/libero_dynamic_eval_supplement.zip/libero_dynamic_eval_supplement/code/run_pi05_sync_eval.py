#!/usr/bin/env python3
"""Pi0.5 synchronous realtime eval entrypoint.

The robot blocks for each Pi0.5 chunk. During the exact inference interval,
MuJoCo physics and dynamic objects continue while robot joints are held. The
latency is not rounded to 20 Hz control ticks.
"""

from __future__ import annotations

import sys

from realtime_eval.runner import main


FIXED_ARGS = {
    "--reviewed-old-physics": None,
    "--control-mode": "sync_hold",
    "--prefetch-threshold": "0",
    "--empty-action": "zero",
}


def main_entry() -> int:
    argv = list(sys.argv[1:])
    for flag, value in reversed(list(FIXED_ARGS.items())):
        if flag not in argv:
            if value is None:
                argv.insert(0, flag)
            else:
                argv[0:0] = [flag, value]
    return main(argv)


if __name__ == "__main__":
    raise SystemExit(main_entry())
