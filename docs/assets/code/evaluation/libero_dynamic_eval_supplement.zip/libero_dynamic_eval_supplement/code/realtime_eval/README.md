# Realtime Evaluation Runtime

This package keeps the simulated world independent from policy scheduling.

## Contract

- Robot actions execute at the configured control frequency.
- Synchronous inference latency advances MuJoCo physics continuously while the
  robot is held; it is not rounded to control ticks.
- Async and RTC availability remains indexed by control ticks.
- Policy controllers never call `env.step()` and never mutate the scene.
- Controllers receive observations and may later enqueue action chunks.
- If no action is available at a tick, the action runtime applies the configured
  empty action (`hold` or `zero`) and records an underflow.

This mirrors a real robot setup: the world keeps moving while policy inference,
network delays, RTC queues, or future-state predictors run outside the world.

## Main Pieces

- `control.py`: shared packets, action queue, latency sampler, controller base
  class, and the controller factory.
- `strategies/sync_hold.py`: synchronous hold-latency baseline.
- `strategies/async_queue.py`: LeRobot official async chunking: trigger by
  `queue_len / chunk_size <= chunk_size_threshold`, skip stale timesteps, and
  merge overlapping future actions with `0.3 * old + 0.7 * new`.
- `strategies/rtc_queue.py`: LeRobot official RTC queueing: pass original
  `prev_chunk_left_over` plus inference delay to the RTC-enabled policy, then
  drop the delay prefix and replace the executable future queue.
- `runtime.py`: one episode orchestrator that connects a world, controller, and
  recorder without letting controllers step the world. Avoid editing this for
  policy ideas unless the world contract itself changes.
- `runner.py`: benchmark entrypoint, sharding, manifests, and summaries.

`protocol.py`, `latency.py`, and `controllers.py` are compatibility import
wrappers so older imports keep working. New code should use `control.py`.

To add a new policy scheduling strategy, copy one file under `strategies/`,
override `should_start_request()`, and register the new mode in
`control.py::build_policy_controller()`. Do not edit `runtime.py` for ordinary
strategy experiments.

## Control Modes

- `sync_hold`: submit a policy request when the action queue is empty, wait for
  it, and advance the world by the exact inference duration while robot joints
  are held. The next action executes after that continuous interval.
- `async_queue`: LeRobot official async client semantics. The default trigger is
  `--chunk-size-threshold 0.5`; the returned chunk replaces the future action
  queue after stale timesteps are skipped. If an incoming timestep overlaps with
  an existing queued timestep, the default aggregate is `weighted_average =
  0.3 * old + 0.7 * new`.
- `rtc_queue`: LeRobot official RTC ActionQueue semantics. Only this mode sends
  RTC conditioning to the policy. The runtime snapshots unconsumed original
  policy actions for `prev_chunk_left_over`, supplies `inference_delay_steps`,
  then replaces the executable queue with returned actions after dropping the
  delay prefix. It does not do client-side weighted overlap.
- `vlash_future_state`: reserved for future-state-aware policies. It should be
  implemented as another controller, not by changing world stepping.

`hold_latency` and `naive_async_queue` are kept as backward-compatible aliases
for older manifests. Do not use the old append-only async queue for formal RTC
claims.

## Latency Sources

- `measured_wallclock`: use actual policy wall-clock time.
- `fixed`: use a calibrated latency value, allowing shared model services and
  high-throughput simulation without contaminating simulated latency.
- `empirical`: sample from a measured latency distribution.

For throughput benchmarks with shared model servers, prefer `fixed` or
`empirical`; otherwise queueing on the shared service becomes part of the
simulated latency.

For queue-ratio triggering, the integer threshold is exactly
`ceil(chunk_size_threshold * action_chunk_size)` and is never silently raised
to the latency budget. RTC results should use `--require-rtc-conditioning`.

## Video Modes

Use `--no-save-review-video --save-model-input-videos
--model-input-video-layout dual --model-input-video-size 128 --video-fps 5
--render-every 4` for compact videos that show agentview and wrist view side by
side without spending most runtime on review rendering.
