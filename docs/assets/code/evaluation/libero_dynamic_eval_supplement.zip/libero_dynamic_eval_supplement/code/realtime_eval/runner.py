from __future__ import annotations

import argparse
import json
import inspect
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import eval_dynamic_libero_style as legacy

from .control import CONTROL_MODE_CHOICES
from .runtime import RealtimeEpisode


if not hasattr(argparse, "BooleanOptionalAction"):
    class _BooleanOptionalAction(argparse.Action):
        def __init__(self, option_strings, dest, default=None, **kwargs):
            options = []
            for option in option_strings:
                options.append(option)
                if option.startswith("--"):
                    options.append("--no-" + option[2:])
            super().__init__(options, dest, nargs=0, default=default, **kwargs)

        def __call__(self, parser, namespace, values, option_string=None):
            setattr(namespace, self.dest, not str(option_string).startswith("--no-"))

    argparse.BooleanOptionalAction = _BooleanOptionalAction


def _patch_legacy_torch_load() -> None:
    try:
        import torch
    except Exception:
        return
    if "weights_only" in inspect.signature(torch.load).parameters:
        return
    original_load = torch.load

    def compatible_load(*args: Any, **kwargs: Any) -> Any:
        kwargs.pop("weights_only", None)
        return original_load(*args, **kwargs)

    torch.load = compatible_load


_patch_legacy_torch_load()


def _assign_worker_egl_device(slot: int) -> None:
    raw = os.environ.get("LIBERO_EGL_DEVICE_IDS", "").strip()
    if not raw:
        return
    devices = [value.strip() for value in raw.replace(";", ",").split(",") if value.strip()]
    if not devices:
        return
    os.environ["MUJOCO_EGL_DEVICE_ID"] = devices[int(slot) % len(devices)]


def write_summary(output_dir: Path, results: list[dict[str, Any]]) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    ordered = sorted(results, key=lambda row: row.get("item_id", ""))
    (output_dir / "manifest.jsonl").write_text(
        "\n".join(json.dumps(row, ensure_ascii=False) for row in ordered) + ("\n" if ordered else ""),
        encoding="utf-8",
    )
    issues = [row for row in ordered if row.get("status") != "ok" or not row.get("diagnostics", {}).get("ok", False)]
    summary = {
        "runtime_version": "realtime_v2",
        "total": len(ordered),
        "ok_status": sum(1 for row in ordered if row.get("status") == "ok"),
        "diagnostic_ok": sum(1 for row in ordered if row.get("diagnostics", {}).get("ok", False)),
        "success_count": sum(1 for row in ordered if row.get("success")),
        "control_modes": sorted({str(row.get("control_mode")) for row in ordered}),
        "policies": sorted({str(row.get("policy")) for row in ordered}),
        "latency_sources": sorted({str(row.get("latency_source")) for row in ordered}),
        "sim_latency_decoupled_from_wallclock": sorted(
            {bool(row.get("sim_latency_decoupled_from_wallclock")) for row in ordered}
        ),
        "shared_policy_latency_contaminated_items": sum(
            1 for row in ordered if row.get("shared_policy_latency_contaminated")
        ),
        "issues": len(issues),
        "issue_items": [
            {
                "item_id": row.get("item_id"),
                "status": row.get("status"),
                "success": row.get("success"),
                "flags": row.get("diagnostics", {}).get("flags", []),
                "error": row.get("error"),
            }
            for row in issues
        ],
    }
    (output_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")


def run_worker_partition(slot: int, items: list[dict[str, Any]], args_dict: dict[str, Any]) -> list[dict[str, Any]]:
    _assign_worker_egl_device(int(slot))
    args = argparse.Namespace(**args_dict)
    results: list[dict[str, Any]] = []
    shard_path = args.output_dir / f"worker_{int(slot):02d}_manifest.jsonl"
    for idx, item in enumerate(items, start=1):
        print(f"[worker {slot}] [{idx}/{len(items)}] {item['item_id']}", flush=True)
        result = RealtimeEpisode(item, args, worker_slot=int(slot)).run()
        print(
            f"[worker {slot}] {result['item_id']} status={result.get('status')} "
            f"success={result.get('success')} diag_ok={result.get('diagnostics', {}).get('ok')}",
            flush=True,
        )
        results.append(result)
        shard_path.write_text(
            "\n".join(json.dumps(row, ensure_ascii=False) for row in results) + "\n",
            encoding="utf-8",
        )
    return results


def _split_round_robin(items: list[dict[str, Any]], num_workers: int) -> list[list[dict[str, Any]]]:
    partitions = [[] for _ in range(int(num_workers))]
    for idx, item in enumerate(items):
        partitions[idx % int(num_workers)].append(item)
    return partitions


def build_parser() -> argparse.ArgumentParser:
    repo_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description="Run LIBERO-Dynamic realtime runtime v2.")
    parser.add_argument("--config-dir", type=Path, default=repo_root / "libero" / "libero" / "dynamic_configs")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--levels", nargs="+", default=["l1", "l2", "l3"])
    parser.add_argument("--traj-indices", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--init-state-id", type=int, default=0)
    parser.add_argument("--num-workers", type=int, default=1)
    parser.add_argument("--start-index", type=int, default=0)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--reviewed-old-physics", action="store_true")

    parser.add_argument(
        "--control-mode",
        choices=CONTROL_MODE_CHOICES,
        default="sync_hold",
        help=(
            "sync_hold: world keeps stepping and the robot sends a zero/no-op action while each chunk is inferred; "
            "async_queue/rtc_queue: prefetch action chunks through an external controller; "
            "vlash_future_state: reserved interface for future-state-aware policies. "
            "hold_latency and naive_async_queue are backward-compatible aliases."
        ),
    )
    parser.add_argument(
        "--prefetch-threshold",
        type=int,
        default=5,
        help="Legacy fixed-step prefetch threshold; used only when --chunk-size-threshold is unset.",
    )
    parser.add_argument(
        "--chunk-size-threshold",
        type=float,
        default=None,
        help=(
            "LeRobot official async/RTC trigger: request a chunk when "
            "queue_len / replan_steps <= threshold. Official default is 0.5."
        ),
    )
    parser.add_argument(
        "--aggregate-fn-name",
        choices=("weighted_average",),
        default="weighted_average",
        help="LeRobot async aggregate function implemented here: 0.3 * old + 0.7 * new.",
    )
    parser.add_argument(
        "--empty-action",
        choices=("hold", "zero"),
        default="zero",
        help=(
            "Action to execute when the policy queue is empty. zero is the real-robot-style hold/no-op for delta "
            "control; hold is the legacy repeat-last-action behavior."
        ),
    )
    parser.add_argument(
        "--freeze-robot-on-underflow",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "When the action queue underflows, restore robot/gripper joint state after the env step so the arm "
            "stays fixed while dynamic scene elements continue to advance. This is the strict real-robot sync hold."
        ),
    )

    parser.add_argument("--policy", choices=("zero", "random", "openpi_ws"), default="zero")
    parser.add_argument("--random-scale", type=float, default=0.02)
    parser.add_argument("--simulated-inference-seconds", type=float, default=0.0)
    parser.add_argument("--openpi-host", default="127.0.0.1")
    parser.add_argument("--openpi-port", type=int, default=8124)
    parser.add_argument("--openpi-resize-size", type=int, default=224)
    parser.add_argument("--replan-steps", type=int, default=10)
    parser.add_argument("--per-worker-policy-endpoint", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--policy-server-count", type=int, default=0)
    parser.add_argument("--policy-port-stride", type=int, default=1)

    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--control-freq", type=int, default=20)
    parser.add_argument(
        "--object-speed-mps",
        type=float,
        default=None,
        help="Formal group speed label written into every manifest row.",
    )
    parser.add_argument("--num-steps-wait", type=int, default=5)
    parser.add_argument("--max-steps", type=int, default=600)
    parser.add_argument("--stop-on-success", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument(
        "--require-rtc-conditioning",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Fail an RTC episode unless the policy server reports genuine RTC conditioning support.",
    )
    parser.add_argument("--latency-mode", choices=("disabled", "measured", "fixed"), default="disabled")
    parser.add_argument("--fixed-inference-seconds", type=float, default=None)
    parser.add_argument("--latency-source", choices=("measured_wallclock", "fixed", "empirical"), default="measured_wallclock")
    parser.add_argument("--calibrated-latency-seconds", type=float, default=None)
    parser.add_argument("--calibrated-first-inference-seconds", type=float, default=None)
    parser.add_argument("--latency-samples-json", type=Path, default=None)
    parser.add_argument("--latency-sample-seed", type=int, default=0)

    parser.add_argument("--save-videos", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--save-review-video", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--save-model-input-videos", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--model-input-video-layout", choices=("agentview", "dual"), default="agentview")
    parser.add_argument("--model-input-video-size", type=int, default=0)
    parser.add_argument("--save-wrist-input-videos", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--save-step-trace", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--video-fps", type=float, default=20.0)
    parser.add_argument("--camera-size", type=int, default=256)
    parser.add_argument("--render-every", type=int, default=1)
    parser.add_argument("--record-warmup", action="store_true")
    parser.add_argument("--record-latency-frames", action=argparse.BooleanOptionalAction, default=False)
    parser.add_argument("--video-style", choices=("libero", "review"), default="review")

    parser.add_argument("--dynamic-phase-prime-steps", type=int, default=0)
    parser.add_argument("--fixture-passenger-phase-prime-steps", type=int, default=None)
    parser.add_argument("--pre-policy-dynamic-steps", type=int, default=0)
    parser.add_argument("--reset-platforms-after-warmup", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--keep-static-support-contact", action="store_true")
    parser.add_argument("--static-support-clearance-m", type=float, default=0.0)
    parser.add_argument("--platform-settle-steps", type=int, default=20)
    parser.add_argument("--realign-after-platform-settle", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--preview-compatible-eval", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--preview-compatible-scope", choices=("fragile", "all"), default="fragile")
    parser.add_argument("--preview-compatible-settle-steps", type=int, default=80)

    parser.add_argument("--platform-error-threshold-m", type=float, default=0.01)
    parser.add_argument("--follow-error-threshold-m", type=float, default=0.08)
    parser.add_argument("--tilt-threshold-deg", type=float, default=35.0)
    parser.add_argument("--drop-threshold-m", type=float, default=0.04)
    parser.add_argument("--bottom-baseline-mode", choices=("first_sample", "reset"), default="first_sample")
    parser.add_argument("--offscreen-ratio-threshold", type=float, default=0.25)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.latency_source == "fixed" and args.calibrated_latency_seconds is None:
        if args.fixed_inference_seconds is not None:
            args.calibrated_latency_seconds = float(args.fixed_inference_seconds)
        else:
            raise ValueError("--calibrated-latency-seconds is required for --latency-source fixed")
    if args.latency_source == "empirical" and args.latency_samples_json is None:
        raise ValueError("--latency-samples-json is required for --latency-source empirical")
    if args.chunk_size_threshold is not None and not (0.0 <= float(args.chunk_size_threshold) <= 1.0):
        raise ValueError("--chunk-size-threshold must be between 0 and 1")
    if int(args.policy_server_count) < 0:
        raise ValueError("--policy-server-count must be >= 0")
    if args.object_speed_mps is not None and float(args.object_speed_mps) <= 0.0:
        raise ValueError("--object-speed-mps must be positive")
    if bool(args.reviewed_old_physics):
        legacy.apply_reviewed_old_physics_profile(args)
    args.output_dir = args.output_dir.expanduser().resolve()
    config_dir = args.config_dir.expanduser().resolve()
    config_path_by_level = legacy.write_effective_config_files(config_dir, args.output_dir, args.levels, args)
    effective_config_dir = args.output_dir / "effective_dynamic_configs"
    items = legacy.build_items(
        effective_config_dir,
        args.levels,
        args.traj_indices,
        keep_static_support_contact=bool(args.keep_static_support_contact),
        static_support_clearance_m=float(args.static_support_clearance_m),
        config_path_by_level=config_path_by_level,
    )
    if args.start_index:
        items = items[int(args.start_index) :]
    if args.limit is not None:
        items = items[: int(args.limit)]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "items.json").write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    args_dict = vars(args).copy()
    results: list[dict[str, Any]] = []
    if int(args.num_workers) <= 1:
        results = run_worker_partition(0, items, args_dict)
    else:
        partitions = _split_round_robin(items, int(args.num_workers))
        with ProcessPoolExecutor(max_workers=int(args.num_workers)) as pool:
            futures = {
                pool.submit(run_worker_partition, slot, partition, args_dict): slot
                for slot, partition in enumerate(partitions)
                if partition
            }
            for future in as_completed(futures):
                slot = futures[future]
                try:
                    results.extend(future.result())
                except Exception as exc:
                    print(f"[worker {slot}] fatal error: {exc!r}", flush=True)
    write_summary(args.output_dir, results)
    return 0
