"""Persistent native FastWAM websocket server, using the official inference kernel."""

import argparse
import asyncio
import json
from pathlib import Path
import time

from native_fastwam_policy import NativeFastWAM


async def serve(policy, port, ledger):
    import websockets
    from openpi_client import msgpack_numpy

    async def handler(websocket, *unused):
        packer = msgpack_numpy.Packer()
        await websocket.send(packer.pack(policy.metadata))
        try:
            async for payload in websocket:
                obs = msgpack_numpy.unpackb(payload)
                if obs.get('reset'):
                    await websocket.send(packer.pack(dict(ok=True)))
                    continue
                started = time.perf_counter()
                result = policy.infer(obs)
                elapsed = time.perf_counter() - started
                with ledger.open('a') as handle:
                    handle.write(json.dumps(dict(time=time.time(), prompt=str(obs.get('prompt')),
                        elapsed_seconds=elapsed, action_shape=list(result['actions'].shape),
                        status='ok', model='fastwam_native', num_inference_steps=1))+'\n')
                result['server_timing'] = dict(infer_ms=1000 * elapsed)
                await websocket.send(packer.pack(result))
        except websockets.exceptions.ConnectionClosed:
            pass

    async with websockets.serve(handler, '127.0.0.1', port, compression=None, max_size=None):
        print(f'native FastWAM server listening port={port}', flush=True)
        await asyncio.Future()


def main():
    parser = argparse.ArgumentParser()
    for name in ('source', 'checkpoint', 'stats', 'metadata', 'ledger'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--port', type=int, required=True)
    args = parser.parse_args()
    policy = NativeFastWAM(args.source, args.checkpoint, args.stats)
    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    args.ledger.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.write_text(json.dumps(policy.metadata, indent=2)+'\n')
    asyncio.run(serve(policy, args.port, args.ledger))


if __name__ == '__main__':
    main()
