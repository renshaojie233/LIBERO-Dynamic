#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import http
import logging
import os
import socket
import time
import traceback

import numpy as np
import torch
import websockets
import websockets.asyncio.server as websocket_server
import websockets.frames
from safetensors.torch import load_model as load_model_as_safetensor

from lerobot.policies import make_pre_post_processors
from lerobot.policies.vla_jepa.configuration_vla_jepa import VLAJEPAConfig
from lerobot.policies.vla_jepa.modeling_vla_jepa import VLAJEPAPolicy
from lerobot.utils.device_utils import resolve_safetensors_device
from openpi_client import msgpack_numpy


NATIVE_HORIZON = 7
ALLOWED_CHECKPOINT_EXTRAS = {
    "model.qwen.model.model.language_model.embed_tokens.weight",
    "model.video_predictor.extrinsics_encoder.bias",
    "model.video_predictor.extrinsics_encoder.weight",
    "model.video_predictor.state_encoder.bias",
    "model.video_predictor.state_encoder.weight",
}


def _rotate_and_format_image(value: object) -> torch.Tensor:
    image = np.asarray(value)
    if image.ndim != 3 or image.shape[-1] != 3:
        raise ValueError(f"expected HWC RGB image, got {image.shape}")
    image = np.ascontiguousarray(image[::-1, ::-1])
    tensor = torch.from_numpy(image).permute(2, 0, 1).to(dtype=torch.float32)
    if tensor.max().item() > 1.0:
        tensor = tensor / 255.0
    return tensor


class AuditedVLAJEPAPolicy(VLAJEPAPolicy):
    @classmethod
    def _load_as_safetensor(cls, model, model_file: str, map_location: str, strict: bool):
        missing, unexpected = load_model_as_safetensor(
            model,
            model_file,
            strict=False,
            device=resolve_safetensors_device(map_location),
        )
        missing = set(missing)
        unexpected = set(unexpected)
        if missing or unexpected != ALLOWED_CHECKPOINT_EXTRAS:
            raise RuntimeError(
                "VLA-JEPA checkpoint audit failed: "
                f"missing={sorted(missing)}, unexpected={sorted(unexpected)}"
            )
        logging.info(
            "Checkpoint audit passed: missing=0, allowed training/tied extras=%s",
            sorted(unexpected),
        )
        return model


class VLAJEPAOfficialPolicy:
    def __init__(self, checkpoint: str, actions_per_chunk: int) -> None:
        torch.manual_seed(7)
        np.random.seed(7)

        config = VLAJEPAConfig.from_pretrained(checkpoint)
        config.device = "cuda"
        self._policy = AuditedVLAJEPAPolicy.from_pretrained(checkpoint, config=config, strict=True)
        self._policy.eval()
        self._preprocess, self._postprocess = make_pre_post_processors(
            policy_cfg=self._policy.config,
            pretrained_path=checkpoint,
            preprocessor_overrides={"device_processor": {"device": "cuda"}},
            postprocessor_overrides={"device_processor": {"device": "cpu"}},
        )
        self._actions_per_chunk = int(actions_per_chunk)

    def reset(self) -> None:
        self._policy.reset()

    @torch.no_grad()
    def infer(self, obs: dict) -> dict:
        state = np.asarray(obs["observation/state"], dtype=np.float32)
        if state.shape != (8,) or not np.isfinite(state).all():
            raise ValueError(f"expected finite 8D state, got {state.shape}")

        frame = {
            "observation.images.image": _rotate_and_format_image(obs["observation/image"]),
            "observation.images.image2": _rotate_and_format_image(obs["observation/wrist_image"]),
            "observation.state": torch.from_numpy(state.copy()),
            "task": str(obs["prompt"]),
        }
        batch = self._preprocess(frame)
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16, enabled=False):
            actions = self._policy.predict_action_chunk(batch)
        actions = self._postprocess(actions)
        if isinstance(actions, torch.Tensor):
            actions = actions.detach().cpu().numpy()
        actions = np.asarray(actions, dtype=np.float32)
        if actions.ndim == 3 and actions.shape[0] == 1:
            actions = actions[0]
        if actions.shape != (NATIVE_HORIZON, 7) or not np.isfinite(actions).all():
            raise RuntimeError(f"invalid VLA-JEPA action chunk: {actions.shape}")
        selected = np.ascontiguousarray(actions[: self._actions_per_chunk])
        return {"actions": selected, "original_actions": selected.copy()}


class ResettingWebsocketPolicyServer:
    def __init__(self, policy: VLAJEPAOfficialPolicy, port: int, metadata: dict) -> None:
        self._policy = policy
        self._port = port
        self._metadata = metadata

    def serve_forever(self) -> None:
        asyncio.run(self._run())

    async def _run(self) -> None:
        async with websocket_server.serve(
            self._handler,
            "0.0.0.0",
            self._port,
            compression=None,
            max_size=None,
            process_request=self._health_check,
        ) as server:
            await server.serve_forever()

    async def _handler(self, websocket: websocket_server.ServerConnection) -> None:
        self._policy.reset()
        packer = msgpack_numpy.Packer()
        await websocket.send(packer.pack(self._metadata))
        previous_total = None
        while True:
            try:
                started = time.monotonic()
                observation = msgpack_numpy.unpackb(await websocket.recv())
                infer_started = time.monotonic()
                result = self._policy.infer(observation)
                result["server_timing"] = {
                    "infer_ms": (time.monotonic() - infer_started) * 1000.0,
                }
                if previous_total is not None:
                    result["server_timing"]["prev_total_ms"] = previous_total * 1000.0
                await websocket.send(packer.pack(result))
                previous_total = time.monotonic() - started
            except websockets.ConnectionClosed:
                break
            except Exception:
                await websocket.send(traceback.format_exc())
                await websocket.close(
                    code=websockets.frames.CloseCode.INTERNAL_ERROR,
                    reason="Internal server error; traceback sent in previous frame",
                )
                raise

    @staticmethod
    async def _health_check(
        connection: websocket_server.ServerConnection,
        request: websocket_server.Request,
    ) -> websocket_server.Response | None:
        if request.path == "/healthz":
            return connection.respond(http.HTTPStatus.OK, "OK\n")
        return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--actions-per-chunk", type=int, required=True)
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()
    if not 1 <= args.actions_per_chunk <= NATIVE_HORIZON:
        raise ValueError(f"actions-per-chunk must be in [1, {NATIVE_HORIZON}]")

    logging.basicConfig(level=logging.INFO)
    policy = VLAJEPAOfficialPolicy(args.checkpoint, args.actions_per_chunk)
    metadata = {
        "model": "vla-jepa",
        "implementation": "official_lerobot_vla_jepa",
        "checkpoint": os.path.realpath(args.checkpoint),
        "checkpoint_provenance": "lerobot/VLA-JEPA-LIBERO",
        "strict_checkpoint_load": "zero_missing_exact_extra_whitelist",
        "allowed_checkpoint_extras": sorted(ALLOWED_CHECKPOINT_EXTRAS),
        "backbone_initialization": "official_config_then_complete_checkpoint",
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "gpu_name": torch.cuda.get_device_name(0),
        "native_action_horizon": NATIVE_HORIZON,
        "actions_per_chunk": args.actions_per_chunk,
        "action_truncation_owner": "policy_server",
        "observation_preprocessing_owner": "policy_server",
        "camera_rotation_degrees": 180,
        "camera_keys": ["observation/image", "observation/wrist_image"],
        "policy_camera_keys": ["observation.images.image", "observation.images.image2"],
        "policy_image_size": 224,
        "uses_proprio": True,
        "state_key": "observation/state",
        "state_dim": 8,
        "preprocessor": "checkpoint_policy_preprocessor",
        "postprocessor": "checkpoint_policy_postprocessor",
        "gripper_postprocess": "official_clip_pre_snap_unnormalize_binarize",
        "websocket_connection_resets_policy": True,
        "rtc_conditioning_supported": False,
        "sampling_global_seed": 7,
    }
    logging.info(
        "Serving VLA-JEPA K=%d on %s:%d", args.actions_per_chunk, socket.gethostname(), args.port
    )
    ResettingWebsocketPolicyServer(policy, args.port, metadata).serve_forever()


if __name__ == "__main__":
    main()
