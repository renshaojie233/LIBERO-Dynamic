"""Official unconditioned FastWAM, not Joint-WAM or an SDP variant."""

import gc
import importlib.metadata
import json
import os
from pathlib import Path
import sys

STANDARD_K_VALUES = (32, 16, 8, 4, 3, 2, 1)
CANDIDATE_K_VALUES = (7, 6, 5)
K_VALUES = (32, 16, 8, 7, 6, 5, 4, 3, 2, 1)
CALIBRATION_BOUNDARY = 'raw RGB/state through local websocket and official preprocessing to postprocessed actions'


class NativeFastWAM:
    def __init__(self, source, checkpoint, stats):
        import numpy as np
        import torch
        from hydra import compose, initialize_config_dir
        from hydra.utils import instantiate

        self.source, self.checkpoint, self.stats = map(lambda p: Path(p).resolve(),
                                                      (source, checkpoint, stats))
        for path in (self.source, self.source/'src', self.source/'experiments/libero'):
            sys.path.insert(0, str(path))
        from experiments.libero.eval_libero_single import _predict_action_chunk
        from fastwam.datasets.lerobot.utils.normalizer import load_dataset_stats_from_json
        from fastwam.models.wan22.fastwam import FastWAM

        with initialize_config_dir(version_base='1.3', config_dir=str(self.source/'configs')):
            self.cfg = compose(config_name='sim_libero', overrides=[
                'task=libero_uncond_2cam224_1e-4', 'model=fastwam',
                f'ckpt={self.checkpoint}', f'EVALUATION.dataset_stats_path={self.stats}',
                'EVALUATION.num_inference_steps=1', 'eval_num_inference_steps=1',
                'EVALUATION.replan_steps=32', 'EVALUATION.action_horizon=32',
                'EVALUATION.sigma_shift=5.0', 'EVALUATION.visualize_future_video=false',
                'EVALUATION.binarize_gripper=true', 'EVALUATION.device=cuda', 'seed=0'])
        if self.cfg.model._target_ != 'fastwam.runtime.create_fastwam':
            raise ValueError('Not the official unconditioned FastWAM target')
        if not torch.cuda.is_available():
            raise RuntimeError('Native FastWAM requires CUDA; no CPU fallback')
        self.model = instantiate(self.cfg.model, model_dtype=torch.bfloat16, device='cuda')
        if type(self.model) is not FastWAM:
            raise ValueError('A Joint/IDM/SDP model cannot be used as native FastWAM')

        # The official loader uses strict=False. Check all task weights before loading.
        payload = torch.load(self.checkpoint, map_location='cpu', mmap=True, weights_only=False)
        weights = payload.get('mot')
        if not isinstance(weights, dict):
            raise ValueError('Official release has no complete MoT weights')
        expected = self.model.mot.state_dict()
        if set(weights) != set(expected):
            raise ValueError(f'Checkpoint key mismatch: missing={set(expected)-set(weights)}, '
                             f'unexpected={set(weights)-set(expected)}')
        if any(weights[k].shape != expected[k].shape for k in expected):
            raise ValueError('Checkpoint tensor shapes differ from the native architecture')
        self.model.mot.load_state_dict(weights, strict=True)
        if self.model.proprio_encoder is None or 'proprio_encoder' not in payload:
            raise ValueError('Missing official proprio encoder')
        self.model.proprio_encoder.load_state_dict(payload['proprio_encoder'], strict=True)
        self.loaded_tensors = len(weights)
        del payload, weights, expected
        gc.collect()
        self.model.eval()
        self.processor = instantiate(self.cfg.data.train.processor).eval()
        self.processor.set_normalizer_from_stats(load_dataset_stats_from_json(str(self.stats)))
        self.predict = _predict_action_chunk
        self.np = np

    @property
    def metadata(self):
        import torch
        return dict(policy='fastwam_native', display_name='FastWAM (official, one denoising step)',
            model_class=f'{type(self.model).__module__}.{type(self.model).__name__}',
            model_target=str(self.cfg.model._target_), task='libero_uncond_2cam224_1e-4',
            checkpoint=str(self.checkpoint),
            dataset_stats=str(self.stats),
            source=str(self.source), action_horizon=32, actions_per_chunk=32,
            num_inference_steps=1, sigma_shift=5.0, seed=0,
            sampling='official infer_action seed=0, rand_device=cpu; independent of worker ordering',
            required_observation_history_frames=1, required_action_history_steps=0,
            rtc_conditioning_supported=False, predicted_video_decoded=False,
            loaded_mot_tensors=self.loaded_tensors,
            input_contract='two RGB cameras, official resize/normalize; 8D state, 32x7D output',
            observation_preprocessing_owner='policy_server',
            image_orientation_fix='raw benchmark images; official preprocessing rotates once',
            gpu_runtime=dict(backend='cuda', name=torch.cuda.get_device_name(0),
                visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
                physical_gpu=os.environ.get('TASK_PHYSICAL_GPU')),
            runtime_versions={p: importlib.metadata.version(p) for p in
                ('torch', 'torchvision', 'numpy', 'hydra-core', 'omegaconf')})

    def infer(self, observation):
        import torch
        np = self.np
        state = np.asarray(observation['observation/state'], dtype=np.float32)
        if state.shape != (8,) or not np.isfinite(state).all():
            raise ValueError('Expected finite 8D LIBERO state')
        vec = state[3:6]
        angle = float(np.linalg.norm(vec))
        quat = (np.array([0, 0, 0, 1], dtype=np.float32) if angle < 1e-8 else
                np.r_[vec / angle * np.sin(angle / 2), np.cos(angle / 2)].astype(np.float32))
        obs = dict(agentview_image=np.ascontiguousarray(observation['observation/image']),
            robot0_eye_in_hand_image=np.ascontiguousarray(observation['observation/wrist_image']),
            robot0_eef_pos=state[:3], robot0_eef_quat=quat, robot0_gripper_qpos=state[6:8])
        with torch.inference_mode():
            actions, _, future = self.predict(obs=obs, task_description=str(observation['prompt']),
                model=self.model, processor=self.processor, cfg=self.cfg,
                action_horizon=32, input_w=448, input_h=224, model_device='cuda')
        actions = np.asarray(actions, dtype=np.float32)
        if actions.shape != (32, 7) or not np.isfinite(actions).all() or future is not None:
            raise ValueError('Invalid native output or unexpected predicted-video decoding')
        return dict(actions=actions, original_actions=actions)


def verify_latency(data):
    meta = data['server_metadata']
    if meta['policy'] != 'fastwam_native' or meta['num_inference_steps'] != 1 \
            or meta['action_horizon'] != 32 or meta['predicted_video_decoded']:
        raise ValueError('Frozen calibration belongs to another model or inference path')
    required_gpu = os.environ.get('FASTWAM_REQUIRED_GPU_SUBSTRING')
    if required_gpu and required_gpu not in meta['gpu_runtime']['name']:
        raise ValueError('Frozen calibration was measured on a different target GPU')
    if len(data['samples']) < 88:
        raise ValueError('Expected a clean calibration with at least 88 samples')
    if data['boundary'] != CALIBRATION_BOUNDARY or meta.get('observation_preprocessing_owner') != 'policy_server':
        raise ValueError('Pure architecture latency is not deployment latency')
    tau = data['median_seconds']
    if not isinstance(tau, (float, int)) or not 0 < tau < 5:
        raise ValueError('Invalid frozen latency')
    return tau
