#!/usr/bin/env python3
from __future__ import annotations

import argparse
import logging
import socket

from openpi.policies import policy_config
from openpi.serving import websocket_policy_server
from openpi.training import config


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--actions-per-chunk", type=int, required=True)
    args = parser.parse_args()
    if not 1 <= args.actions_per_chunk <= 50:
        raise ValueError("actions-per-chunk must be in [1, 50]")

    policy = policy_config.create_trained_policy(
        config.get_config("pi0_libero"), args.checkpoint
    )
    metadata = dict(policy.metadata)
    metadata.update(
        {
            "model": "pi0",
            "implementation": "openpi_jax",
            "policy_config": "pi0_libero",
            "checkpoint": args.checkpoint,
            "checkpoint_provenance": "official_openpi",
            "native_action_horizon": 50,
            "actions_per_chunk": args.actions_per_chunk,
            "action_truncation_owner": "benchmark_client_replan_steps",
            "camera_keys": ["observation/image", "observation/wrist_image"],
            "state_key": "observation/state",
            "websocket_connection_resets_policy": True,
            "rtc_conditioning_supported": False,
        }
    )
    hostname = socket.gethostname()
    logging.info("Creating pi0 server on %s:%d", hostname, args.port)
    websocket_policy_server.WebsocketPolicyServer(
        policy=policy, host="0.0.0.0", port=args.port, metadata=metadata
    ).serve_forever()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, force=True)
    main()
