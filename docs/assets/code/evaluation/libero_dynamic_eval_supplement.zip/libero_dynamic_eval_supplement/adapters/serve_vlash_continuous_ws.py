#!/usr/bin/env python3
"""Serve a VLASH PI0.5 checkpoint through the OpenPI websocket protocol."""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import logging
import os
import time
import traceback
from pathlib import Path
from typing import Any

import msgpack
import numpy as np
import torch
import websockets

import vlash.configs  # noqa: F401 - registers VLASH policy configs
from lerobot.configs.policies import PreTrainedConfig
from vlash.policies.factory import get_policy_class

try:
    from transformers.utils import LossKwargs  # noqa: F401
except ImportError:
    from typing import TypedDict
    import transformers.utils

    class LossKwargs(TypedDict, total=False):
        pass

    transformers.utils.LossKwargs = LossKwargs


def _pack_array(obj: Any) -> Any:
    if isinstance(obj, (np.ndarray, np.generic)) and obj.dtype.kind in ("V", "O", "c"):
        raise ValueError(f"Unsupported dtype: {obj.dtype}")
    if isinstance(obj, np.ndarray):
        return {
            b"__ndarray__": True,
            b"data": obj.tobytes(),
            b"dtype": obj.dtype.str,
            b"shape": obj.shape,
        }
    if isinstance(obj, np.generic):
        return {
            b"__npgeneric__": True,
            b"data": obj.item(),
            b"dtype": obj.dtype.str,
        }
    return obj


def _unpack_array(obj: dict[Any, Any]) -> Any:
    if b"__ndarray__" in obj:
        return np.ndarray(buffer=obj[b"data"], dtype=np.dtype(obj[b"dtype"]), shape=obj[b"shape"])
    if b"__npgeneric__" in obj:
        return np.dtype(obj[b"dtype"]).type(obj[b"data"])
    return obj


def _image_tensor(value: Any, device: str) -> torch.Tensor:
    array = np.asarray(value)
    if array.ndim != 3:
        raise ValueError(f"Expected an HWC or CHW image, got shape {array.shape}")
    tensor = torch.as_tensor(np.array(array, copy=True), dtype=torch.float32, device=device)
    if tensor.shape[-1] == 3:
        tensor = tensor.permute(2, 0, 1)
    if tensor.numel() and float(tensor.max().item()) > 1.5:
        tensor = tensor / 255.0
    return tensor.contiguous().unsqueeze(0)


class VLASHOpenPIWS:
    def __init__(self, checkpoint: str, device: str, actions_per_chunk: int) -> None:
        self.checkpoint = str(Path(checkpoint).expanduser().resolve())
        self.device = str(device)
        self.actions_per_chunk = int(actions_per_chunk)
        torch.set_num_threads(1)

        config = PreTrainedConfig.from_pretrained(
            self.checkpoint,
            local_files_only=True,
        )
        config.device = self.device
        config.n_action_steps = self.actions_per_chunk
        config.pretrained_path = self.checkpoint
        if hasattr(config, "compile_model"):
            config.compile_model = False
        if hasattr(config, "gradient_checkpointing"):
            config.gradient_checkpointing = False

        policy_class = get_policy_class(config.type)
        self.policy = policy_class.from_pretrained(
            self.checkpoint,
            config=config,
            local_files_only=True,
        )
        self.policy.to(self.device)
        self.policy.eval()

    @property
    def metadata(self) -> dict[str, Any]:
        return {
            "policy": "vlash_pi05",
            "checkpoint": self.checkpoint,
            "actions_per_chunk": self.actions_per_chunk,
            "device": self.device,
            "rtc_conditioning_supported": False,
            "required_observation_history_frames": 1,
            "required_action_history_steps": 0,
            "websocket_connection_resets_policy": True,
            "vlash_state_semantics": "client_supplied_nominal_future_state",
            "vlash_visual_delay_semantics": "current_image_at_request_submit",
            "vlash_official_libero_chunk_size": self.actions_per_chunk,
            "vlash_protocol": "vlash_continuous_libero_free_space_osc_v2",
            "released_official_libero_shortcut": False,
            "native_prediction_horizon": 50,
            "num_inference_steps": int(self.policy.config.num_inference_steps),
            "sampling_seed_contract": "sha256(request_key), independent of worker/gpu scheduling",
            "checkpoint_sha256": os.environ.get("VLASH_CHECKPOINT_SHA256"),
            "vlash_chunk_merge": "intact_no_weighting",
        }

    def reset(self) -> None:
        self.policy.reset()

    def infer(self, obs: dict[str, Any]) -> dict[str, Any]:
        state = torch.as_tensor(
            np.array(obs["observation/state"], dtype=np.float32, copy=True),
            dtype=torch.float32,
            device=self.device,
        ).unsqueeze(0)
        batch = {
            "observation.images.image": _image_tensor(
                obs["observation/image"], self.device
            ),
            "observation.images.wrist_image": _image_tensor(
                obs["observation/wrist_image"], self.device
            ),
            "observation.state": state,
            "task": str(obs.get("prompt", "")),
        }

        key = str(obs["vlash_request_key"])
        seed = int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], "big") % (2**63 - 1)
        devices = [torch.cuda.current_device()] if self.device.startswith("cuda") else []
        with torch.random.fork_rng(devices=devices), torch.inference_mode():
            torch.manual_seed(seed)
            chunk = self.policy.predict_action_chunk(batch)
        actions = (
            chunk[0, : self.actions_per_chunk, :]
            .detach()
            .to(device="cpu", dtype=torch.float32)
            .numpy()
        )
        return {
            "actions": actions,
            "original_actions": np.array(actions, copy=True),
        }


class WebsocketServer:
    def __init__(self, policy: VLASHOpenPIWS, host: str, port: int) -> None:
        self.policy = policy
        self.host = str(host)
        self.port = int(port)
        self.packer = msgpack.Packer(default=_pack_array)

    async def handler(self, websocket: Any) -> None:
        self.policy.reset()
        await websocket.send(self.packer.pack(self.policy.metadata))
        previous_total_s = None
        while True:
            try:
                request_started = time.monotonic()
                obs = msgpack.unpackb(
                    await websocket.recv(),
                    object_hook=_unpack_array,
                )
                inference_started = time.monotonic()
                result = self.policy.infer(obs)
                inference_s = time.monotonic() - inference_started
                result["server_timing"] = {"infer_ms": inference_s * 1000.0}
                if previous_total_s is not None:
                    result["server_timing"]["prev_total_ms"] = previous_total_s * 1000.0
                await websocket.send(self.packer.pack(result))
                previous_total_s = time.monotonic() - request_started
            except websockets.ConnectionClosed:
                break
            except Exception:
                logging.exception("VLASH inference failed")
                await websocket.send(traceback.format_exc())
                await websocket.close(code=1011, reason="Internal server error")
                raise

    async def run(self) -> None:
        async with websockets.serve(
            self.handler,
            self.host,
            self.port,
            compression=None,
            max_size=None,
        ):
            await asyncio.Future()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=18240)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--actions-per-chunk", type=int, default=5)
    return parser.parse_args()


def main() -> int:
    logging.basicConfig(level=logging.INFO, force=True)
    args = parse_args()
    policy = VLASHOpenPIWS(
        checkpoint=args.checkpoint,
        device=args.device,
        actions_per_chunk=args.actions_per_chunk,
    )
    logging.info("Serving VLASH policy: %s", policy.metadata)
    asyncio.run(WebsocketServer(policy, args.host, args.port).run())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
