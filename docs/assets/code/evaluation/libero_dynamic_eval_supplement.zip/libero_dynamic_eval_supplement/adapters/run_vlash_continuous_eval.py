#!/usr/bin/env python3
"""Register a new strategy without changing the historical controller."""

import os
from pathlib import Path
import sys

REPO = Path(
    os.environ.get(
        "VLASH_EVAL_REPO",
        Path(__file__).resolve().parent / "vlash_reference_repo",
    )
).resolve()
sys.path.insert(0, str(REPO / "scripts"))

from realtime_eval import control
from vlash_continuous import VLASHContinuousController

old_build_controller = control.build_policy_controller
control.CONTROL_MODE_CHOICES += ("vlash_continuous",)


def build_controller(**kwargs):
    if kwargs["mode"] == "vlash_continuous":
        return VLASHContinuousController(**kwargs)
    return old_build_controller(**kwargs)


control.build_policy_controller = build_controller

import eval_dynamic_libero_style as legacy

old_build_policy = legacy.build_policy
old_observation = legacy.OpenPIWebsocketPolicy._observation


def build_policy(args, env, item):
    policy = old_build_policy(args, env, item)
    wrapped = getattr(env, "env", env)
    robot = wrapped.robots[0]
    osc = robot.controller
    if not osc.use_delta or osc.impedance_mode != "fixed" or osc.control_dim != 6:
        raise ValueError("VLASH predictor requires fixed six-dimensional delta OSC_POSE")
    if osc.position_limits is not None or osc.orientation_limits is not None:
        raise ValueError("Unimplemented pose limits; refusing unvalidated prediction")
    policy.vlash_osc_spec = {name: __import__("numpy").asarray(getattr(osc, name)).tolist()
        for name in ("input_min", "input_max", "output_min", "output_max", "kp", "kd")}
    policy.vlash_osc_spec['control_dt']=1/args.control_freq
    return policy


def observation(self, obs, language):
    request = old_observation(self, obs, language)
    request["vlash_request_key"] = obs["__vlash_request_key"]
    return request


legacy.build_policy = build_policy
legacy.OpenPIWebsocketPolicy._observation = observation

from realtime_eval.runner import main

if __name__ == "__main__":
    raise SystemExit(main())
