#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import logging
import os
import socket
from types import SimpleNamespace

import numpy as np
import torch

from openpi.serving import websocket_policy_server


SUITES = ("libero_spatial", "libero_object", "libero_goal", "libero_10")


def _postprocess_gripper(actions: np.ndarray) -> np.ndarray:
    result = np.asarray(actions, dtype=np.float32).copy()
    result[..., -1] = 2.0 * result[..., -1] - 1.0
    result[..., -1] = np.sign(result[..., -1])
    result[..., -1] *= -1.0
    return result


class OpenVLAOfficialPolicy:
    def __init__(self, checkpoint: str, suite: str) -> None:
        from experiments.robot.robot_utils import get_action, set_seed_everywhere
        from prismatic.extern.hf.configuration_prismatic import OpenVLAConfig
        from prismatic.extern.hf.modeling_prismatic import OpenVLAForActionPrediction
        from prismatic.extern.hf.processing_prismatic import (
            PrismaticImageProcessor,
            PrismaticProcessor,
        )
        from transformers import (
            AutoConfig,
            AutoImageProcessor,
            AutoModelForVision2Seq,
            AutoProcessor,
        )

        self._get_action = get_action
        self._suite = suite
        self._cfg = SimpleNamespace(
            model_family="openvla",
            pretrained_checkpoint=checkpoint,
            load_in_8bit=False,
            load_in_4bit=False,
            center_crop=True,
            unnorm_key=suite,
        )
        set_seed_everywhere(7)
        AutoConfig.register("openvla", OpenVLAConfig)
        AutoImageProcessor.register(OpenVLAConfig, PrismaticImageProcessor)
        AutoProcessor.register(OpenVLAConfig, PrismaticProcessor)
        AutoModelForVision2Seq.register(OpenVLAConfig, OpenVLAForActionPrediction)
        self._model = AutoModelForVision2Seq.from_pretrained(
            checkpoint,
            attn_implementation="flash_attention_2",
            torch_dtype=torch.bfloat16,
            load_in_8bit=False,
            load_in_4bit=False,
            low_cpu_mem_usage=True,
            trust_remote_code=False,
        )
        self._model.eval().to(torch.device("cuda:0"))
        with open(os.path.join(checkpoint, "dataset_statistics.json"), "r") as stream:
            self._model.norm_stats = json.load(stream)
        if suite not in self._model.norm_stats and f"{suite}_no_noops" in self._model.norm_stats:
            self._cfg.unnorm_key = f"{suite}_no_noops"
        if self._cfg.unnorm_key not in self._model.norm_stats:
            raise KeyError(f"missing normalization key: {self._cfg.unnorm_key}")
        self._processor = AutoProcessor.from_pretrained(
            checkpoint, trust_remote_code=False
        )

    def infer(self, obs: dict) -> dict:
        import tensorflow as tf

        image = np.ascontiguousarray(np.asarray(obs["observation/image"])[::-1, ::-1])
        image = tf.image.encode_jpeg(image)
        image = tf.io.decode_image(image, expand_animations=False, dtype=tf.uint8)
        image = tf.image.resize(image, (224, 224), method="lanczos3", antialias=True)
        image = tf.cast(tf.clip_by_value(tf.round(image), 0, 255), tf.uint8).numpy()
        action = self._get_action(
            self._cfg,
            self._model,
            {"full_image": image},
            str(obs["prompt"]),
            processor=self._processor,
        )
        actions = _postprocess_gripper(np.asarray(action).reshape(1, 7))
        if actions.shape != (1, 7) or not np.isfinite(actions).all():
            raise RuntimeError(f"invalid OpenVLA action shape or values: {actions.shape}")
        return {"actions": actions, "original_actions": actions.copy()}


class OpenVLAOFTOfficialPolicy:
    def __init__(self, checkpoint: str, suite: str, actions_per_chunk: int) -> None:
        from experiments.robot.openvla_utils import (
            get_action_head,
            get_processor,
            get_proprio_projector,
        )
        from experiments.robot.robot_utils import get_action, set_seed_everywhere
        from prismatic.extern.hf.configuration_prismatic import OpenVLAConfig
        from prismatic.extern.hf.modeling_prismatic import OpenVLAForActionPrediction
        from prismatic.extern.hf.processing_prismatic import (
            PrismaticImageProcessor,
            PrismaticProcessor,
        )
        from transformers import (
            AutoConfig,
            AutoImageProcessor,
            AutoModelForVision2Seq,
            AutoProcessor,
        )

        self._get_action = get_action
        self._actions_per_chunk = int(actions_per_chunk)
        self._cfg = SimpleNamespace(
            model_family="openvla",
            pretrained_checkpoint=checkpoint,
            use_l1_regression=True,
            use_diffusion=False,
            num_diffusion_steps_train=50,
            num_diffusion_steps_inference=50,
            use_film=False,
            num_images_in_input=2,
            use_proprio=True,
            center_crop=True,
            num_open_loop_steps=8,
            lora_rank=32,
            unnorm_key=suite,
            load_in_8bit=False,
            load_in_4bit=False,
        )
        set_seed_everywhere(7)
        AutoConfig.register("openvla", OpenVLAConfig)
        AutoImageProcessor.register(OpenVLAConfig, PrismaticImageProcessor)
        AutoProcessor.register(OpenVLAConfig, PrismaticProcessor)
        AutoModelForVision2Seq.register(OpenVLAConfig, OpenVLAForActionPrediction)
        self._model = AutoModelForVision2Seq.from_pretrained(
            checkpoint,
            torch_dtype=torch.bfloat16,
            load_in_8bit=False,
            load_in_4bit=False,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        )
        self._model.vision_backbone.set_num_images_in_input(2)
        self._model.eval().to(torch.device("cuda:0"))
        with open(os.path.join(checkpoint, "dataset_statistics.json"), "r") as stream:
            self._model.norm_stats = json.load(stream)
        if suite not in self._model.norm_stats and f"{suite}_no_noops" in self._model.norm_stats:
            self._cfg.unnorm_key = f"{suite}_no_noops"
        if self._cfg.unnorm_key not in self._model.norm_stats:
            raise KeyError(f"missing normalization key: {self._cfg.unnorm_key}")
        self._processor = get_processor(self._cfg)
        self._proprio_projector = get_proprio_projector(
            self._cfg, self._model.llm_dim, proprio_dim=8
        )
        self._action_head = get_action_head(self._cfg, self._model.llm_dim)

    def infer(self, obs: dict) -> dict:
        full_image = np.ascontiguousarray(np.asarray(obs["observation/image"])[::-1, ::-1])
        wrist_image = np.ascontiguousarray(
            np.asarray(obs["observation/wrist_image"])[::-1, ::-1]
        )
        actions = self._get_action(
            self._cfg,
            self._model,
            {
                "full_image": full_image,
                "wrist_image": wrist_image,
                "state": np.asarray(obs["observation/state"], dtype=np.float32).copy(),
            },
            str(obs["prompt"]),
            processor=self._processor,
            action_head=self._action_head,
            proprio_projector=self._proprio_projector,
            noisy_action_projector=None,
            use_film=False,
        )
        original = _postprocess_gripper(np.asarray(actions, dtype=np.float32))
        if original.shape != (8, 7) or not np.isfinite(original).all():
            raise RuntimeError(f"invalid OpenVLA-OFT action chunk: {original.shape}")
        selected = original[: self._actions_per_chunk]
        return {"actions": selected, "original_actions": selected.copy()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("openvla", "openvla-oft"), required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--suite", choices=SUITES, required=True)
    parser.add_argument("--actions-per-chunk", type=int, required=True)
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()

    native_horizon = 1 if args.model == "openvla" else 8
    if not 1 <= args.actions_per_chunk <= native_horizon:
        raise ValueError(f"actions-per-chunk must be in [1, {native_horizon}]")
    if args.model == "openvla" and args.actions_per_chunk != 1:
        raise ValueError("OpenVLA has a native one-action horizon; only K=1 is valid")

    import tensorflow as tf

    tf.config.set_visible_devices([], "GPU")

    if args.model == "openvla":
        policy = OpenVLAOfficialPolicy(args.checkpoint, args.suite)
    else:
        policy = OpenVLAOFTOfficialPolicy(
            args.checkpoint, args.suite, args.actions_per_chunk
        )

    metadata = {
        "model": args.model,
        "implementation": "official_pytorch",
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "gpu_name": torch.cuda.get_device_name(0),
        "runtime_overlay": os.environ.get("TORCH_RUNTIME_OVERLAY"),
        "checkpoint": args.checkpoint,
        "checkpoint_provenance": "official_release",
        "offline_local_autoclass": True,
        "suite": args.suite,
        "native_action_horizon": native_horizon,
        "actions_per_chunk": args.actions_per_chunk,
        "action_truncation_owner": "policy_server",
        "observation_preprocessing_owner": "policy_server",
        "camera_rotation_degrees": 180,
        "policy_image_size": 224,
        "center_crop": True,
        "camera_keys": (
            ["observation/image"]
            if args.model == "openvla"
            else ["observation/image", "observation/wrist_image"]
        ),
        "uses_proprio": args.model == "openvla-oft",
        "state_key": "observation/state" if args.model == "openvla-oft" else None,
        "gripper_postprocess": "normalize_binarize_then_invert",
        "websocket_connection_resets_policy": True,
        "rtc_conditioning_supported": False,
    }
    logging.info(
        "Serving %s suite=%s K=%d on %s:%d",
        args.model,
        args.suite,
        args.actions_per_chunk,
        socket.gethostname(),
        args.port,
    )
    websocket_policy_server.WebsocketPolicyServer(
        policy=policy, host="0.0.0.0", port=args.port, metadata=metadata
    ).serve_forever()


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, force=True)
    torch.set_grad_enabled(False)
    main()
