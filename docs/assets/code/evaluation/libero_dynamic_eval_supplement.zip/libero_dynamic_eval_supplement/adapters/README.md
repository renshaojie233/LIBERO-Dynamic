# Policy Adapters

Every model is exposed through the same websocket contract. The evaluator sends
two RGB images, an 8-D LIBERO robot state, and a language instruction. The
server returns a finite `float32` action chunk and policy metadata.

## Contract

Required request keys are `observation/image`,
`observation/wrist_image`, `observation/state`, and `prompt`. The response must
contain `actions` with shape `[H, 7]`, where `H >= K`. `original_actions` is
also required for RTC because it preserves the policy-space chunk used as
conditioning.

Server metadata records the public model identifier, native horizon, returned
action count, preprocessing ownership, inference steps, and whether genuine RTC
conditioning is supported. A run claiming RTC is invalid unless both the
handshake and episode manifest confirm that conditioning was supported and used.

## Model-to-adapter map

| Model family | Adapter | Notes |
|---|---|---|
| Pi0.5 JAX and Pi0.5 Dynamic FT | `serve_openpi_jax_ws.py` | Official OpenPI policy loader; select the public config and checkpoint at launch |
| Pi0 JAX | `serve_pi0_jax_ws.py` | Official `pi0_libero` deployment |
| Pi0.5 PyTorch, including RTC | `serve_lerobot_pi05_openpi_ws.py` | Enable RTC only for RTC experiments |
| VLA-JEPA | `serve_vla_jepa_ws.py` | Official LeRobot preprocessing and checkpoint audit |
| OpenVLA-OFT | `serve_openvla_family_ws.py` | Use `--model openvla-oft`; native horizon is eight |
| FastWAM-Joint, Single-frame Joint FT, History-frame Joint, and History-frame Joint FT | `serve_fastwam_joint_openpi_ws.py` | Select the public task/model config and checkpoint; one denoising step in the reported experiments |
| FastWAM | `serve_native_fastwam_ws.py` | Official unconditioned model path; one denoising step and no future-video decoding |
| VLASH continuous | `serve_vlash_continuous_ws.py` | Use with `run_vlash_continuous_eval.py` and the pinned reference runtime |

The same adapter may serve a base or fine-tuned checkpoint. This is deliberate:
the matched fine-tuning comparisons change weights, not the environment or
controller implementation.

## Example launches

Arguments below are placeholders, not local paths from the experiments.

```bash
# Pi0 JAX
python adapters/serve_pi0_jax_ws.py \
  --checkpoint "$PI0_JAX_CHECKPOINT" --actions-per-chunk 8 --port 8124

# Pi0.5 PyTorch without RTC
python adapters/serve_lerobot_pi05_openpi_ws.py \
  --checkpoint "$PI05_PYTORCH_CHECKPOINT" \
  --local-tokenizer "$PALIGEMMA_LOCAL_TOKENIZER" \
  --actions-per-chunk 6 --no-enable-rtc --port 8124

# Pi0.5 PyTorch with genuine RTC conditioning
python adapters/serve_lerobot_pi05_openpi_ws.py \
  --checkpoint "$PI05_PYTORCH_CHECKPOINT" \
  --local-tokenizer "$PALIGEMMA_LOCAL_TOKENIZER" \
  --actions-per-chunk 16 --enable-rtc --rtc-execution-horizon 16 --port 8124

# VLA-JEPA
python adapters/serve_vla_jepa_ws.py \
  --checkpoint "$VLA_JEPA_CHECKPOINT" --actions-per-chunk 4 --port 8124

# OpenVLA-OFT
python adapters/serve_openvla_family_ws.py \
  --model openvla-oft --checkpoint "$OPENVLA_OFT_CHECKPOINT" \
  --suite libero_spatial --actions-per-chunk 4 --port 8124

# FastWAM-Joint family
python adapters/serve_fastwam_joint_openpi_ws.py \
  --fastwam-root "$FASTWAM_SOURCE" \
  --checkpoint "$FASTWAM_JOINT_CHECKPOINT" \
  --dataset-stats "$FASTWAM_DATASET_STATS" \
  --task-config libero_joint_2cam224_1e-4 --model-config fastwam_joint \
  --num-inference-steps 1 --actions-per-chunk 8 --port 8124

# Native FastWAM
python adapters/serve_native_fastwam_ws.py \
  --source "$FASTWAM_SOURCE" --checkpoint "$FASTWAM_CHECKPOINT" \
  --stats "$FASTWAM_DATASET_STATS" --metadata "$OUTPUT/metadata.json" \
  --ledger "$OUTPUT/inference.jsonl" --port 8124

# VLASH continuous-world policy endpoint
python adapters/serve_vlash_continuous_ws.py \
  --checkpoint "$VLASH_CHECKPOINT" --actions-per-chunk 5 --port 8124
```

OpenPI JAX uses Tyro's tagged checkpoint argument. Run
`python adapters/serve_openpi_jax_ws.py --help` against the pinned OpenPI
version and supply the public policy config plus checkpoint; do not rely on a
machine-local default.

Checkpoint paths are launch arguments or environment variables. Never place
local paths, host names, user names, access tokens, or private asset hashes in a
double-blind release. Runtime metadata must be sanitized before publication.

