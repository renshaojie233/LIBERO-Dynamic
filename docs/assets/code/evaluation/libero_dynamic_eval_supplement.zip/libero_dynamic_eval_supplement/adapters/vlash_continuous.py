"""Causal LIBERO adaptation of VLASH; not the released delayed-image shortcut."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any

import numpy as np
from scipy.spatial.transform import Rotation

from realtime_eval.control import (
    ActionChunkPacket,
    ActionRuntime,
    ChunkQueueControllerBase,
    ObservationPacket,
)

PROTOCOL = "vlash_continuous_libero_free_space_osc_v2"


def nominal_terminal_state(obs: dict, queued: np.ndarray, spec: dict,
    linear_velocity=None, angular_velocity=None, horizon=None) -> dict:
    """Predict free-space OSC spring response; no future scene or observation."""
    state = {key: np.array(obs[key], copy=True) for key in (
        "robot0_eef_pos", "robot0_eef_quat", "robot0_gripper_qpos"
    )}
    position = np.asarray(state["robot0_eef_pos"], dtype=float)
    rotation = Rotation.from_quat(state["robot0_eef_quat"])
    low, high = np.array(spec["input_min"]), np.array(spec["input_max"])
    out_low, out_high = np.array(spec["output_min"]), np.array(spec["output_max"])
    kp, kd = np.array(spec["kp"]), np.array(spec["kd"])
    if not np.allclose(kd, 2*np.sqrt(kp), rtol=1e-6):
        raise ValueError("Only critical-damping OSC has been implemented")
    dt = float(spec["control_dt"])
    omega = np.sqrt(kp)
    decay = np.exp(-omega*dt)
    velocity = np.concatenate((np.zeros(3) if linear_velocity is None else linear_velocity,
        np.zeros(3) if angular_velocity is None else angular_velocity))
    controls = list(queued)
    controls.extend(np.zeros(7) for _ in range(max(0, int(horizon or len(queued))-len(queued))))
    for action in controls:
        delta = np.clip(np.asarray(action[:6], dtype=float), low, high)
        delta = out_low + (delta - low) * (out_high - out_low) / (high - low)
        displacement = delta*(1-(1+omega*dt)*decay) + velocity*dt*decay
        velocity = delta*kp*dt*decay + velocity*(1-omega*dt)*decay
        position = position + displacement[:3]
        rotation = Rotation.from_rotvec(displacement[3:]) * rotation
    state["robot0_eef_pos"] = position
    state["robot0_eef_quat"] = rotation.as_quat()
    # Contacts and actuator state cannot be inferred exactly from an EEF command.
    # Persistence is explicit, rather than fabricating future finger positions.
    return state


class VLASHContinuousController(ChunkQueueControllerBase):
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        if self.latency_sampler.source != "fixed" or not self.latency_sampler.fixed_seconds:
            raise ValueError("This comparison requires a positive frozen deployment latency")
        if self.chunk_size_threshold is not None:
            raise ValueError("VLASH uses latency-budget lookahead, not async queue blending")
        self.spec = self.policy.vlash_osc_spec
        self.overlap = min(self.action_chunk_size, self.latency_budget_steps())
        self.event_file = None
        self.pending_prediction = None
        self.prediction_error_m = []
        self.previous_packet = None
        self.linear_velocity = np.zeros(3)
        self.angular_velocity = np.zeros(3)

    def reset(self) -> None:
        super().reset()
        self.pending_prediction = None
        self.prediction_error_m = []
        self.previous_packet = None
        self.linear_velocity = np.zeros(3)
        self.angular_velocity = np.zeros(3)

    def record_observation(self, packet: ObservationPacket) -> None:
        if self.previous_packet is not None:
            dt = packet.sim_time_s - self.previous_packet.sim_time_s
            if dt <= 0:
                raise ValueError("Non-monotonic observation clock")
            self.linear_velocity = (packet.obs['robot0_eef_pos'] -
                self.previous_packet.obs['robot0_eef_pos'])/dt
            self.angular_velocity = (Rotation.from_quat(packet.obs['robot0_eef_quat']) *
                Rotation.from_quat(self.previous_packet.obs['robot0_eef_quat']).inv()).as_rotvec()/dt
        self.previous_packet = ObservationPacket(packet.episode_id,packet.step_idx,packet.sim_time_s,
            packet.language,{key:np.array(packet.obs[key],copy=True) for key in
                ('robot0_eef_pos','robot0_eef_quat')},packet.queue_len,packet.last_action.copy())
        super().record_observation(packet)

    def event(self, packet: ObservationPacket, kind: str, **values: Any) -> None:
        if self.event_file is None:
            root = Path(os.environ["VLASH_EVENT_DIR"])
            root.mkdir(parents=True, exist_ok=True)
            safe_id = re.sub(r"[^A-Za-z0-9_.-]", "_", packet.episode_id)
            self.event_file = root / (safe_id + ".jsonl")
            if self.event_file.exists():
                raise RuntimeError(f"Refusing to overwrite request events: {self.event_file}")
        with self.event_file.open("a") as handle:
            handle.write(json.dumps(dict(event=kind, step_idx=packet.step_idx,
                sim_time_s=packet.sim_time_s, **values), allow_nan=False) + "\n")

    def should_start_request(self, actions: ActionRuntime) -> bool:
        return actions.queue_len <= self.overlap

    def snapshot_request_observation(self, packet: ObservationPacket, actions: ActionRuntime) -> dict:
        snapshot = super().snapshot_request_observation(packet, actions)
        queued = actions.snapshot_actions(original=False)
        predicted = nominal_terminal_state(snapshot, queued, self.spec,
            self.linear_velocity,self.angular_velocity,
            max(len(queued),self.latency_budget_steps()))
        snapshot.update(predicted)
        key = f"{os.environ['VLASH_SPEED']}|{packet.episode_id}|{self.prefetch_count}|{packet.step_idx}"
        snapshot["__vlash_request_key"] = hashlib.sha256(key.encode()).hexdigest()
        self.pending_prediction = dict(
            predicted_state={k: v.tolist() for k, v in predicted.items()},
            visual_observation_step_idx=int(packet.step_idx),
            predicted_handoff_step_idx=int(packet.step_idx + max(len(queued), self.latency_budget_steps())),
            queued_actions_at_submit=len(queued),
            request_key=snapshot["__vlash_request_key"],
        )
        self.event(packet, "submit", **self.pending_prediction,
            input_state_source="free_space_osc_response_at_submit_gripper_persistence",
            causal_linear_velocity=self.linear_velocity.tolist(),
            causal_angular_velocity=self.angular_velocity.tolist(),
            queued_actions=queued.tolist(),
            observed_state={k: np.asarray(packet.obs[k]).tolist() for k in predicted},
            due_step_idx=int(self.pending_available_step_idx))
        return snapshot

    def merge_ready_packet(self, actions: ActionRuntime, packet: ActionChunkPacket) -> dict:
        if actions.queue_len:
            raise RuntimeError("VLASH handoff attempted before committed chunk exhausted")
        count = actions.enqueue(packet)
        return dict(strategy="intact_replace_no_weighting", overlap=0, appended=count, dropped_prefix=0)

    def _enqueue_if_available(self, packet: ObservationPacket, actions: ActionRuntime) -> list:
        # A computed chunk may wait for the committed actions to finish. Never
        # launch another request or merge chunks while this result is waiting.
        if actions.queue_len:
            return []
        ready = super()._enqueue_if_available(packet, actions)
        for chunk in ready:
            prediction = self.pending_prediction
            if prediction is None:
                raise RuntimeError("Missing request-time state prediction")
            predicted = prediction["predicted_state"]
            error = float(np.linalg.norm(np.asarray(predicted["robot0_eef_pos"]) - packet.obs["robot0_eef_pos"]))
            orientation_error = float((Rotation.from_quat(predicted["robot0_eef_quat"]) *
                Rotation.from_quat(packet.obs["robot0_eef_quat"]).inv()).magnitude())
            gripper_error = float(np.linalg.norm(np.asarray(predicted["robot0_gripper_qpos"]) -
                packet.obs["robot0_gripper_qpos"]))
            self.prediction_error_m.append(error)
            chunk.metadata.update(prediction, vlash_protocol=PROTOCOL,
                handoff_step_idx=int(packet.step_idx), predicted_eef_position_error_m=error,
                predicted_eef_orientation_error_rad=orientation_error,
                predicted_gripper_state_error_l2=gripper_error,
                future_state_oracle=False, weighted_blending=False)
            self.event(packet, "handoff", request_key=prediction["request_key"],
                submit_step_idx=chunk.submit_step_idx, due_step_idx=chunk.available_step_idx,
                queued_actions_before_handoff=0, actions=len(chunk.actions),
                predicted_eef_position_error_m=error,
                predicted_eef_orientation_error_rad=orientation_error,
                predicted_gripper_state_error_l2=gripper_error,
                actual_state_at_handoff={k: np.asarray(packet.obs[k]).tolist() for k in predicted})
            self.pending_prediction = None
        return ready

    def summary(self) -> dict:
        return dict(super().summary(), vlash_protocol=PROTOCOL,
            continuous_world=True, future_state_oracle=False,
            image_source="current_at_request_submit_no_extra_visual_delay",
            future_state_predictor="critical_damping_free_space_osc_response_v2",
            gripper_state_predictor="persistence_at_submit",
            predictor_is_exact_dynamics=False, osc_contract=self.spec,
            prefetch_overlap_steps=self.overlap, overlap_rule="min(K, ceil(frozen_latency * control_freq))",
            chunk_merge="intact_replace_no_weighting_no_prefix_drop",
            startup_latency_applied=True, latency_double_counted=False,
            request_events=None if self.event_file is None else str(self.event_file),
            state_predictions_audited=len(self.prediction_error_m),
            predicted_eef_position_error_mean_m=(None if not self.prediction_error_m
                else float(np.mean(self.prediction_error_m))),
            simulation_clock="frozen_target_latency; host compute barriers do not count as target time")
