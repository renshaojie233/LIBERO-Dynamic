# LIBERO-Dynamic Evaluation Supplement

This directory is the double-blind-safe entry point for reproducing the paper's
LIBERO-Dynamic evaluations. It separates benchmark semantics, model deployment,
result auditing, and paper tables so that a change in one layer cannot silently
change another.

Python 3.10 or newer is required; the model environments may impose stricter
version and accelerator requirements.

## Scope

The package covers four experiment families and the benchmark data artifacts
needed to interpret them:

1. Original-model asynchronous comparison: Pi0.5 JAX, Pi0 JAX, VLA-JEPA,
   OpenVLA-OFT, FastWAM-Joint, and FastWAM.
2. Pi0.5 PyTorch execution methods: Sync, Async, RTC with a proportional
   threshold, RTC with a fixed ten-step threshold, and the continuous-world
   VLASH adaptation.
3. Idealized zero-latency synchronous Pi0.5 PyTorch evaluation.
4. Three dynamic-data fine-tuned models: Pi0.5, single-frame Joint, and
   history-frame Joint.
5. A compact representative gallery: four task subsets by three motion
   families at 0.09 m/s, with reviewed clips and uniformly sampled stills.
6. A complete video gallery covering all 40 tasks and all three motion families
   at 0.09 m/s: 120 consistently named third-person clips.
7. The dynamic-demonstration generator and the exact/non-benchmark phase
   partition builder used for dataset construction.

The result CSV files contain only measured values. Missing or incomplete groups
remain missing; no value is interpolated or estimated.

## Canonical benchmark contract

- Control frequency: 20 Hz.
- Episode limit: 600 control steps.
- Stop immediately on task success.
- Object speeds: 0.03, 0.06, and 0.09 m/s.
- Per-speed set: 600 canonical `(speed, item_id)` entries.
- Complete group: 1,800 unique entries, all `status=ok`, zero errors, and 1,800
  valid step traces when trace-level metrics are claimed.
- Success rate: all successful episodes divided by 1,800. It is never filtered
  by `diagnostics.ok` or trace availability.
- Deployment-latency experiments use a frozen target latency. Shared-server
  wall-clock contention is recorded but does not replace that latency.
- The world clock advances during inference. Sync uses the exact frozen latency
  as continuous MuJoCo physics time while robot joints are held; Async and RTC
  quantize queue availability to 20 Hz control ticks.

The machine-readable version is in `protocol/protocol_spec.json`.

## Controller definitions

- **Sync** (`sync_hold`): request a new chunk only after the executable queue is
  empty. During the exact frozen inference interval, the dynamic world advances
  in physics substeps and the robot joints are held. The interval is not rounded
  to a whole number of control ticks.
- **Async** (`async_queue`): request when
  `queue_len <= ceil(0.5 * action_chunk_size)`; discard stale returned timesteps and
  merge overlapping future actions as `0.3 * old + 0.7 * new`.
- **RTC proportional**: use RTC policy conditioning and the same 0.5 queue-ratio
  request threshold. Drop the measured delay prefix and replace the future
  executable queue; do not apply client-side weighted blending.
  Formal RTC runs fail fast unless the server reports genuine RTC conditioning.
- **RTC fixed-10**: the same RTC handoff semantics, but request when ten actions
  remain. This is a separate protocol and is never merged with proportional
  RTC.
- **Sync zero latency**: the Sync controller with frozen latency set to exactly
  zero. It is an idealized ablation and is reported separately.
- **VLASH continuous**: a Pi0.5-based co-designed checkpoint/controller that
  predicts a causal nominal future robot state while the world continues. It is
  not a scheduling-only ablation of the vanilla Pi0.5 checkpoint.

## Files

- `protocol/protocol_spec.json`: frozen benchmark and controller semantics.
- `configs/model_registry.json`: public model/deployment metadata and checkpoint
  environment-variable names.
- `configs/paper_experiments.json`: configurations used by paper tables and
  figures.
- `tables/original_models_async.csv`: best complete asynchronous point for each
  original model.
- `tables/pi05_execution_strategies.csv`: measured Pi0.5 strategy sweep.
- `tables/pi05_sync_zero_latency.csv`: strict 1,800-episode zero-latency groups.
- `tables/dynamic_finetuning.csv`: matched base and Dynamic-FT comparisons.
- `tables/latency_calibrations.csv`: audited warm-up and retained-sample counts
  for every frozen latency used by the paper configurations.
- `tables/excluded_or_historical.csv`: measurements that must not be mixed into
  the formal comparisons.
- `scripts/run_group.py`: constructs and runs one three-speed benchmark group.
- `scripts/audit_group.py`: strict manifest/trace completeness audit.
- `scripts/check_double_blind.py`: scans a release tree for identity and
  infrastructure leakage.
- `scripts/audit_media_budget.py`: inventories all MP4 files and checks the
  100 MiB submission budget before real-robot videos are added.
- `scripts/build_release.py`: assembles the public evaluation code and refuses
  to finish if the double-blind scan fails.
- `CODE_MAP.md`: exact public code paths and their role in the protocol.
- `PAPER_ALIGNMENT.md`: manuscript-facing selection rules and the exact rows
  used by the current comparisons.
- `adapters/`: anonymous policy-server entry points for every reported model
  family, including the pinned continuous-world VLASH extension.
- `task_gallery/`: 12 reviewed dual-view representative trajectories, 96
  agent-view stills, appendix-ready contact sheets, and a complete 120-video
  agent-view gallery spanning 40 tasks by three motion families. Both galleries
  have checksum manifests.
- `data_generation/`: the template-replay demonstration generator and the
  phase-disjoint dataset partition builder.
- `MEDIA_BUDGET.md`: video quality and staged compression policy. Videos are
  retained as primary electronic-supplement artifacts; stills do not replace
  them.

## Reproduction outline

Start one OpenPI-compatible policy endpoint per evaluator worker. Checkpoint
paths are supplied through the environment variables named in
`configs/model_registry.json`; they are intentionally absent from this package.

Print the commands for a paper configuration before running it:

```bash
python supplementary/libero_dynamic_evaluation/scripts/run_group.py \
  --experiment pi05_pytorch_async_k6 \
  --config-root "$LIBERO_DYNAMIC_SPEED_CONFIG_ROOT" \
  --output-root "$OUTPUT_ROOT" \
  --policy-host 127.0.0.1 \
  --policy-port 8124 \
  --dry-run
```

Remove `--dry-run` only after the policy metadata and command have been checked.
After evaluation:

```bash
python supplementary/libero_dynamic_evaluation/scripts/audit_group.py \
  "$OUTPUT_ROOT/pi05_pytorch_async_k6" \
  --require-traces \
  --required-trace-field eef_pos \
  --required-trace-field action_delta_l2 \
  --required-trace-field underflow \
  --output "$OUTPUT_ROOT/pi05_pytorch_async_k6/strict_audit.json"
```

Only an audit with `complete=true` is eligible for a formal table.

## Latency calibration provenance

`tables/latency_calibrations.csv` is the public, double-blind-safe calibration
manifest. Its counts were transcribed only after checking the retained source
records. `warmup_total` counts requests discarded before measurement;
`retained_total` counts requests that enter the reported median. For a
two-process calibration, the per-run columns describe each independent process
and the total columns sum both runs. VLA-JEPA retained three rounds of 100
requests per process, hence 300 retained requests per run and 600 in total.

Fine-tuned checkpoints that preserve the deployment path reuse the matching
base calibration instead of claiming a second measurement. The intentional
zero-latency Sync ablation has zero warm-up and zero retained latency samples
because it is not a measured calibration. The history-frame Joint source is an
original frozen-calibration record with explicit `warmup=20` and
`measured=100`; its public row records that evidence granularity rather than
claiming that request-level samples are bundled here.

## Double-blind release

Run:

```bash
python supplementary/libero_dynamic_evaluation/scripts/build_release.py
```

The builder copies the protocol runtime and selected model adapters into a
clean `dist/` tree, runs scheduling regression tests, creates
`dist/libero_dynamic_eval_supplement.zip`, then rejects private filesystem
paths, SSH material, and non-loopback IP addresses. Private host aliases, user names, and project words
are supplied at scan time through `DOUBLE_BLIND_DENY_TOKENS`, so the deny-list
itself is never stored in the release. Runtime-produced metadata can contain a
user-supplied checkpoint path; sanitize such metadata before submission.

## Interpretation guardrails

- Frozen deployment latency is not pure model-only `infer_action` latency.
- `diagnostics.ok` is a physical/dynamic validity diagnostic, not task success.
- Zero-latency Sync is not directly interchangeable with deployment-latency
  Sync.
- The continuous-world VLASH adaptation must not be replaced by the historical
  delayed-image/current-state shortcut.
- RTC proportional and RTC fixed-10 are different protocols and must retain
  distinct labels.
- Pi0.5 JAX and Pi0.5 PyTorch are distinct deployments.
- The radar profiles are descriptive and must not be interpreted as scalar
  rankings.
