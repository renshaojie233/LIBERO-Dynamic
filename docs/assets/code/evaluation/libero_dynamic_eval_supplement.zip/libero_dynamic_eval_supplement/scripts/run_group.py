#!/usr/bin/env python3
"""Run one paper configuration over all three LIBERO-Dynamic speeds."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
from typing import Any


SUPPLEMENT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = Path(__file__).resolve().parents[3]


def load_experiment(experiment_id: str) -> dict[str, Any]:
    path = SUPPLEMENT_ROOT / "configs" / "paper_experiments.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    matches = [row for row in data["experiments"] if row["id"] == experiment_id]
    if len(matches) != 1:
        raise ValueError(f"Expected one experiment named {experiment_id!r}, found {len(matches)}")
    return matches[0]


def speed_dir(config_root: Path, speed: str) -> Path:
    candidates = (config_root / f"speed_{speed}", config_root / speed)
    for candidate in candidates:
        if candidate.is_dir():
            return candidate.resolve()
    raise FileNotFoundError(f"Missing speed {speed} config below {config_root}")


def controller_args(name: str) -> list[str]:
    if name in {"sync", "sync_zero_latency"}:
        return [
            "--control-mode", "sync_hold",
            "--prefetch-threshold", "0",
            "--empty-action", "zero",
        ]
    if name == "async":
        return [
            "--control-mode", "async_queue",
            "--chunk-size-threshold", "0.5",
            "--aggregate-fn-name", "weighted_average",
            "--empty-action", "hold",
        ]
    if name == "rtc_ratio":
        return [
            "--control-mode", "rtc_queue",
            "--chunk-size-threshold", "0.5",
            "--empty-action", "hold",
        ]
    if name == "rtc_fixed_10":
        return [
            "--control-mode", "rtc_queue",
            "--prefetch-threshold", "10",
            "--empty-action", "hold",
        ]
    if name == "vlash_continuous":
        return [
            "--control-mode", "vlash_continuous",
            "--prefetch-threshold", "0",
            "--empty-action", "zero",
        ]
    raise ValueError(f"Unsupported controller {name!r}")


def entrypoint(experiment: dict[str, Any], override: Path | None) -> Path:
    if override is not None:
        return override.resolve()
    if experiment["controller"] == "vlash_continuous":
        candidate = SUPPLEMENT_ROOT / "adapters" / "run_vlash_continuous_eval.py"
    else:
        candidates = (
            SUPPLEMENT_ROOT / "code" / "run_realtime_eval.py",
            REPO_ROOT / "scripts" / "run_realtime_eval.py",
        )
        candidate = next((path for path in candidates if path.is_file()), candidates[0])
    if not candidate.is_file():
        raise FileNotFoundError(
            f"Missing evaluator entrypoint {candidate}. Use --entrypoint when running from a built release."
        )
    return candidate


def build_command(
    experiment: dict[str, Any],
    evaluator: Path,
    config_dir: Path,
    output_dir: Path,
    args: argparse.Namespace,
    speed: str,
) -> list[str]:
    latency_s = float(experiment["latency_ms"]) / 1000.0
    command = [
        args.python,
        str(evaluator),
        "--config-dir", str(config_dir),
        "--output-dir", str(output_dir),
        "--levels", "l1", "l2", "l3",
        "--traj-indices", "0", "1", "2", "3", "4",
        "--num-workers", str(args.num_workers),
        "--reviewed-old-physics",
        "--policy", "openpi_ws",
        "--openpi-host", args.policy_host,
        "--openpi-port", str(args.policy_port),
        "--policy-server-count", str(args.policy_server_count),
        "--policy-port-stride", str(args.policy_port_stride),
        "--openpi-resize-size", str(args.resize_size),
        "--replan-steps", str(experiment["k"]),
        "--control-freq", "20",
        "--object-speed-mps", f"{int(speed) / 100.0:.2f}",
        "--max-steps", "600",
        "--stop-on-success",
        "--latency-source", "fixed",
        "--calibrated-latency-seconds", f"{latency_s:.15g}",
        "--no-save-videos",
        "--no-save-review-video",
        "--no-save-model-input-videos",
        "--no-save-wrist-input-videos",
        "--save-step-trace",
        "--record-latency-frames",
        "--camera-size", "256",
        "--render-every", "1",
        "--keep-static-support-contact",
        "--static-support-clearance-m", "0.001",
    ]
    command.extend(controller_args(str(experiment["controller"])))
    if str(experiment["controller"]).startswith("rtc_"):
        command.append("--require-rtc-conditioning")
    command.extend(args.extra_arg)
    return command


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", required=True)
    parser.add_argument("--config-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--policy-host", default="127.0.0.1")
    parser.add_argument("--policy-port", type=int, default=8124)
    parser.add_argument("--policy-server-count", type=int, default=1)
    parser.add_argument("--policy-port-stride", type=int, default=1)
    parser.add_argument("--num-workers", type=int, default=1)
    parser.add_argument("--resize-size", type=int, default=224)
    parser.add_argument("--python", default=sys.executable)
    parser.add_argument("--entrypoint", type=Path, default=None)
    parser.add_argument("--extra-arg", action="append", default=[])
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    experiment = load_experiment(args.experiment)
    evaluator = entrypoint(experiment, args.entrypoint)
    output_root = args.output_root.expanduser().resolve() / args.experiment
    output_root.mkdir(parents=True, exist_ok=True)
    plan = {
        "experiment": experiment,
        "config_root": str(args.config_root.expanduser().resolve()),
        "output_root": str(output_root),
        "policy_host": args.policy_host,
        "policy_port": args.policy_port,
        "policy_server_count": args.policy_server_count,
        "num_workers": args.num_workers,
    }
    (output_root / "public_run_plan.json").write_text(
        json.dumps(plan, indent=2) + "\n", encoding="utf-8"
    )
    for speed in ("003", "006", "009"):
        config_dir = speed_dir(args.config_root.expanduser().resolve(), speed)
        output_dir = output_root / f"speed_{speed}" / "evaluation"
        output_dir.mkdir(parents=True, exist_ok=True)
        command = build_command(experiment, evaluator, config_dir, output_dir, args, speed)
        print(shlex.join(command), flush=True)
        if not args.dry_run:
            environment = dict(os.environ)
            if experiment["controller"] == "vlash_continuous":
                environment.setdefault(
                    "VLASH_EVAL_REPO",
                    str(SUPPLEMENT_ROOT / "adapters" / "vlash_reference_repo"),
                )
                environment["VLASH_SPEED"] = speed
                environment["VLASH_EVENT_DIR"] = str(output_dir / "request_events")
            subprocess.run(command, check=True, env=environment)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
