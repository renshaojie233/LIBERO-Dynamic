#!/usr/bin/env python3
"""Cross-check result arithmetic and experiment/model references."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]


REQUIRED_RUNTIME_FILES = (
    "code/dynamic_motion_invariants.py",
    "code/eval_dynamic_dummy_policy.py",
    "code/eval_dynamic_libero_style.py",
    "code/render_dynamic_config_previews.py",
    "code/rebuild_dynamic_configs_from_manual_json.py",
    "code/run_realtime_eval.py",
    "code/realtime_eval/control.py",
    "code/realtime_eval/runtime.py",
    "code/realtime_eval/runner.py",
    "code/realtime_eval/strategies/sync_hold.py",
    "code/realtime_eval/strategies/async_queue.py",
    "code/realtime_eval/strategies/rtc_queue.py",
    "adapters/serve_lerobot_pi05_openpi_ws.py",
    "adapters/serve_fastwam_joint_openpi_ws.py",
)


def check_release_tree() -> None:
    missing = [name for name in REQUIRED_RUNTIME_FILES if not (ROOT / name).is_file()]
    if missing:
        raise AssertionError(f"Missing runtime files: {missing}")
    junk = [
        str(path.relative_to(ROOT))
        for path in ROOT.rglob("*")
        if path.is_file() and (path.name == ".DS_Store" or path.suffix == ".pyc")
    ]
    if junk:
        raise AssertionError(f"Release contains generated filesystem junk: {junk}")
    for path in ROOT.rglob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")


def rows(name: str) -> list[dict[str, str]]:
    with (ROOT / "tables" / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def truth(value: str) -> bool:
    return value.strip().lower() == "true"


def check_complete_rows(name: str) -> None:
    for row in rows(name):
        if not truth(row.get("complete", "false")):
            continue
        episodes = int(row["episodes"])
        successes = int(row["successes"])
        rate = float(row["success_rate"])
        errors = int(row["errors"])
        if episodes != 1800 or errors != 0:
            raise AssertionError(f"{name}: invalid complete row {row}")
        if not math.isclose(rate, successes / episodes, rel_tol=0.0, abs_tol=1e-12):
            raise AssertionError(f"{name}: success-rate mismatch {row}")


def check_latency_calibrations(experiments: list[dict[str, object]]) -> None:
    calibration_rows = rows("latency_calibrations.csv")
    calibration_ids = [row["calibration_id"] for row in calibration_rows]
    if len(calibration_ids) != len(set(calibration_ids)):
        raise AssertionError("Duplicate latency calibration IDs")
    calibrations = {row["calibration_id"]: row for row in calibration_rows}

    for row in calibration_rows:
        runs = int(row["independent_runs"])
        warmup_per_run = int(row["warmup_per_run"])
        warmup_total = int(row["warmup_total"])
        retained_per_run = int(row["retained_per_run"])
        retained_total = int(row["retained_total"])
        latency_ms = float(row["frozen_latency_ms"])
        if warmup_total != runs * warmup_per_run:
            raise AssertionError(f"Warm-up count mismatch: {row}")
        if retained_total != runs * retained_per_run:
            raise AssertionError(f"Retained-sample count mismatch: {row}")
        if latency_ms == 0.0:
            if row["calibration_id"] != "intentional_zero_latency" or any(
                value != 0
                for value in (runs, warmup_per_run, warmup_total, retained_per_run, retained_total)
            ):
                raise AssertionError(f"Invalid zero-latency calibration row: {row}")
        elif (
            runs <= 0
            or warmup_per_run <= 0
            or retained_per_run <= 0
            or row["raw_record_granularity"] == "not_applicable"
        ):
            raise AssertionError(f"Incomplete measured calibration row: {row}")

    for experiment in experiments:
        calibration_id = str(experiment.get("latency_calibration_id", ""))
        if calibration_id not in calibrations:
            raise AssertionError(
                f"Unknown latency calibration for {experiment['id']}: {calibration_id}"
            )
        expected = float(calibrations[calibration_id]["frozen_latency_ms"])
        actual = float(experiment["latency_ms"])
        if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=1e-9):
            raise AssertionError(
                f"Latency/calibration mismatch for {experiment['id']}: "
                f"{actual} != {expected}"
            )

    measured_latencies = [
        float(row["frozen_latency_ms"])
        for row in calibration_rows
        if float(row["frozen_latency_ms"]) > 0.0
    ]
    for name in (
        "original_models_async.csv",
        "pi05_execution_strategies.csv",
        "dynamic_finetuning.csv",
    ):
        for row in rows(name):
            latency = float(row["frozen_latency_ms"])
            if not any(
                math.isclose(latency, expected, rel_tol=0.0, abs_tol=1e-9)
                for expected in measured_latencies
            ):
                raise AssertionError(f"{name}: unregistered frozen latency {latency}")


def check_task_gallery() -> None:
    gallery = ROOT / "task_gallery"
    selection = json.loads((gallery / "selection.json").read_text(encoding="utf-8"))
    manifest = json.loads((gallery / "gallery_manifest.json").read_text(encoding="utf-8"))
    if float(selection["speed_mps"]) != 0.09 or int(selection["frames_per_clip"]) != 8:
        raise AssertionError("Unexpected gallery speed or frame count")
    tasks = selection["tasks"]
    if len(tasks) != 4 or {task["subset"] for task in tasks} != {
        "spatial", "object", "goal", "long_horizon"
    }:
        raise AssertionError("Gallery must contain the four canonical task subsets")
    for task in tasks:
        if {clip["level"] for clip in task["clips"]} != {"l1", "l2", "l3"}:
            raise AssertionError(f"Missing gallery motion family: {task['subset']}")
    if (
        manifest["clip_count"] != 12
        or manifest["still_count"] != 96
        or manifest["contact_sheet_count"] != 12
    ):
        raise AssertionError("Gallery manifest cardinality mismatch")
    for clip in manifest["clips"]:
        if not (gallery / clip["video"]).is_file():
            raise AssertionError(f"Missing gallery video: {clip['video']}")
        if not (gallery / clip["contact_sheet"]).is_file():
            raise AssertionError(f"Missing contact sheet: {clip['contact_sheet']}")
        if len(clip["frames"]) != 8:
            raise AssertionError(f"Wrong still count: {clip['video']}")
        for frame in clip["frames"]:
            if not (gallery / frame["file"]).is_file():
                raise AssertionError(f"Missing still: {frame['file']}")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def check_full_video_gallery() -> None:
    root = ROOT / "task_gallery" / "full_video_gallery"
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    expected_motions = {"linear", "curvilinear", "zigzag"}
    videos = manifest["videos"]
    if (
        manifest["schema"] != "libero_dynamic_full_video_gallery_v1"
        or float(manifest["speed_mps"]) != 0.09
        or int(manifest["task_count"]) != 40
        or int(manifest["motion_count_per_task"]) != 3
        or int(manifest["video_count"]) != 120
        or len(videos) != 120
    ):
        raise AssertionError("Full video gallery cardinality or protocol mismatch")
    files = [row["file"] for row in videos]
    if len(files) != len(set(files)):
        raise AssertionError("Duplicate full-gallery video path")
    if sum(int(row["size_bytes"]) for row in videos) != int(manifest["total_video_bytes"]):
        raise AssertionError("Full-gallery byte total mismatch")
    for task_id in range(1, 41):
        task_rows = [row for row in videos if int(row["global_task_id_one_based"]) == task_id]
        if len(task_rows) != 3 or {row["motion"] for row in task_rows} != expected_motions:
            raise AssertionError(f"Incomplete full-gallery coverage for T{task_id:02d}")
        for row in task_rows:
            checks = row["selection_checks"]
            if not all(bool(value) for value in checks.values()):
                raise AssertionError(f"Failed source-selection check: {row['file']}")
            if float(row["speed_mps"]) != 0.09:
                raise AssertionError(f"Wrong full-gallery speed: {row['file']}")
            path = root / row["file"]
            if not path.is_file() or path.stat().st_size != int(row["size_bytes"]):
                raise AssertionError(f"Missing or size-mismatched video: {row['file']}")
            if file_sha256(path) != row["sha256"]:
                raise AssertionError(f"Full-gallery checksum mismatch: {row['file']}")


def main() -> int:
    check_release_tree()
    registry = json.loads((ROOT / "configs/model_registry.json").read_text(encoding="utf-8"))
    models = {row["id"] for row in registry["models"]}
    experiments = json.loads(
        (ROOT / "configs/paper_experiments.json").read_text(encoding="utf-8")
    )["experiments"]
    ids = [row["id"] for row in experiments]
    if len(ids) != len(set(ids)):
        raise AssertionError("Duplicate experiment IDs")
    missing_models = sorted({row["model_id"] for row in experiments} - models)
    if missing_models:
        raise AssertionError(f"Unknown model IDs: {missing_models}")
    check_latency_calibrations(experiments)
    for name in (
        "original_models_async.csv",
        "pi05_execution_strategies.csv",
        "pi05_sync_zero_latency.csv",
        "dynamic_finetuning.csv",
    ):
        check_complete_rows(name)
    original = rows("original_models_async.csv")
    if len(original) != 6 or any(row["controller"] != "async_queue" for row in original):
        raise AssertionError("Original-model table must contain six async rows")
    zero = rows("pi05_sync_zero_latency.csv")
    if any(float(row["frozen_latency_ms"]) != 0.0 for row in zero):
        raise AssertionError("Zero-latency table contains nonzero latency")
    paired: dict[str, list[dict[str, str]]] = {}
    for row in rows("dynamic_finetuning.csv"):
        paired.setdefault(row["comparison"], []).append(row)
    for comparison, group in paired.items():
        if len(group) != 2 or {row["variant"] for row in group} != {"Base", "Dynamic FT"}:
            raise AssertionError(f"Bad matched comparison {comparison}")
        keys = {(row["controller"], row["k"], row["frozen_latency_ms"]) for row in group}
        if len(keys) != 1:
            raise AssertionError(f"Unmatched protocol in {comparison}: {keys}")
    check_task_gallery()
    check_full_video_gallery()
    subprocess.run(
        [sys.executable, str(ROOT / "scripts" / "test_runtime_protocol.py")],
        check=True,
    )
    print("Package validation passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
