#!/usr/bin/env python3
"""Build a clean double-blind evaluation-code release."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys


SUPPLEMENT = Path(__file__).resolve().parents[1]
REPO = Path(__file__).resolve().parents[3]
DESTINATION = SUPPLEMENT / "dist" / "libero_dynamic_eval_supplement"
ARCHIVE = SUPPLEMENT / "dist" / "libero_dynamic_eval_supplement.zip"
MAX_RELEASE_BYTES = 100 * 1024 * 1024

CORE_FILES = {
    "scripts/dynamic_motion_invariants.py": "code/dynamic_motion_invariants.py",
    "scripts/eval_dynamic_dummy_policy.py": "code/eval_dynamic_dummy_policy.py",
    "scripts/eval_dynamic_libero_style.py": "code/eval_dynamic_libero_style.py",
    "scripts/render_dynamic_config_previews.py": "code/render_dynamic_config_previews.py",
    "scripts/rebuild_dynamic_configs_from_manual_json.py": "code/rebuild_dynamic_configs_from_manual_json.py",
    "scripts/run_realtime_eval.py": "code/run_realtime_eval.py",
    "scripts/run_pi05_sync_eval.py": "code/run_pi05_sync_eval.py",
    "scripts/run_pi05_async_eval.py": "code/run_pi05_async_eval.py",
    "scripts/run_pi05_rtc_eval.py": "code/run_pi05_rtc_eval.py",
    "scripts/realtime_eval/__init__.py": "code/realtime_eval/__init__.py",
    "scripts/realtime_eval/control.py": "code/realtime_eval/control.py",
    "scripts/realtime_eval/controllers.py": "code/realtime_eval/controllers.py",
    "scripts/realtime_eval/latency.py": "code/realtime_eval/latency.py",
    "scripts/realtime_eval/protocol.py": "code/realtime_eval/protocol.py",
    "scripts/realtime_eval/runtime.py": "code/realtime_eval/runtime.py",
    "scripts/realtime_eval/runner.py": "code/realtime_eval/runner.py",
    "scripts/realtime_eval/README.md": "code/realtime_eval/README.md",
    "scripts/realtime_eval/strategies/__init__.py": "code/realtime_eval/strategies/__init__.py",
    "scripts/realtime_eval/strategies/sync_hold.py": "code/realtime_eval/strategies/sync_hold.py",
    "scripts/realtime_eval/strategies/async_queue.py": "code/realtime_eval/strategies/async_queue.py",
    "scripts/realtime_eval/strategies/naive_async_queue.py": "code/realtime_eval/strategies/naive_async_queue.py",
    "scripts/realtime_eval/strategies/rtc_queue.py": "code/realtime_eval/strategies/rtc_queue.py",
    "scripts/serve_lerobot_pi05_openpi_ws.py": "adapters/serve_lerobot_pi05_openpi_ws.py",
    "scripts/serve_fastwam_joint_openpi_ws.py": "adapters/serve_fastwam_joint_openpi_ws.py"
}


def copy_public_package() -> None:
    if DESTINATION.exists():
        shutil.rmtree(DESTINATION)
    DESTINATION.mkdir(parents=True)
    for source in SUPPLEMENT.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(SUPPLEMENT)
        if relative.parts[0] in {"dist", "__pycache__"} or "__pycache__" in relative.parts:
            continue
        if source.name == ".DS_Store" or source.suffix == ".pyc":
            continue
        target = DESTINATION / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def copy_runtime() -> None:
    for source_name, target_name in CORE_FILES.items():
        source = REPO / source_name
        if not source.is_file():
            raise FileNotFoundError(source)
        target = DESTINATION / target_name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)


def write_checksums() -> None:
    rows = []
    for path in sorted(DESTINATION.rglob("*")):
        if not path.is_file() or path.name == "SHA256SUMS.json":
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        rows.append({"path": str(path.relative_to(DESTINATION)), "sha256": digest})
    (DESTINATION / "SHA256SUMS.json").write_text(
        json.dumps(rows, indent=2) + "\n", encoding="utf-8"
    )


def remove_generated_junk() -> None:
    for path in sorted(DESTINATION.rglob("*.pyc")):
        path.unlink()
    for path in sorted(DESTINATION.rglob("__pycache__"), reverse=True):
        if path.is_dir():
            shutil.rmtree(path)
    for path in DESTINATION.rglob(".DS_Store"):
        path.unlink()


def enforce_size_budget() -> int:
    total = sum(path.stat().st_size for path in DESTINATION.rglob("*") if path.is_file())
    if total > MAX_RELEASE_BYTES:
        raise RuntimeError(
            f"Release size {total / 1024 / 1024:.2f} MiB exceeds the 100 MiB limit"
        )
    return total


def build_archive() -> int:
    if ARCHIVE.exists():
        ARCHIVE.unlink()
    shutil.make_archive(
        str(ARCHIVE.with_suffix("")),
        "zip",
        root_dir=DESTINATION.parent,
        base_dir=DESTINATION.name,
    )
    size = ARCHIVE.stat().st_size
    if size > MAX_RELEASE_BYTES:
        raise RuntimeError(
            f"Archive size {size / 1024 / 1024:.2f} MiB exceeds the 100 MiB limit"
        )
    return size


def main() -> int:
    copy_public_package()
    copy_runtime()
    subprocess.run(
        [sys.executable, str(DESTINATION / "scripts" / "validate_package.py")],
        check=True,
        env={**dict(os.environ), "PYTHONDONTWRITEBYTECODE": "1"},
    )
    subprocess.run(
        [
            sys.executable,
            str(DESTINATION / "scripts" / "check_double_blind.py"),
            str(DESTINATION),
        ],
        check=True,
        env={**dict(os.environ), "PYTHONDONTWRITEBYTECODE": "1"},
    )
    remove_generated_junk()
    write_checksums()
    total = enforce_size_budget()
    archive_size = build_archive()
    print(
        f"{DESTINATION} ({total / 1024 / 1024:.2f} MiB); "
        f"{ARCHIVE} ({archive_size / 1024 / 1024:.2f} MiB)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
