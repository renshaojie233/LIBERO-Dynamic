#!/usr/bin/env python3
"""Audit supplementary videos and enforce the 100 MiB package budget."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[1]
MAX_BYTES = 100 * 1024 * 1024


def probe(path: Path) -> dict[str, object]:
    result = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=codec_name,pix_fmt,width,height,r_frame_rate:format=duration,size",
            "-of",
            "json",
            str(path),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return json.loads(result.stdout)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    if shutil.which("ffprobe") is None:
        raise RuntimeError("ffprobe is required for media validation")

    files = [
        path
        for path in root.rglob("*")
        if path.is_file()
        and "dist" not in path.relative_to(root).parts
        and "__pycache__" not in path.relative_to(root).parts
    ]
    total_bytes = sum(path.stat().st_size for path in files)
    rows = []
    for path in sorted(path for path in files if path.suffix.lower() == ".mp4"):
        metadata = probe(path)
        stream = metadata["streams"][0]
        size = int(metadata["format"]["size"])
        rows.append(
            {
                "file": str(path.relative_to(root)),
                "size_bytes": size,
                "duration_seconds": float(metadata["format"]["duration"]),
                "codec": stream["codec_name"],
                "pixel_format": stream["pix_fmt"],
                "width": int(stream["width"]),
                "height": int(stream["height"]),
                "frame_rate": stream["r_frame_rate"],
            }
        )
    report = {
        "schema": "supplementary_media_budget_v1",
        "limit_bytes": MAX_BYTES,
        "total_bytes": total_bytes,
        "remaining_bytes": MAX_BYTES - total_bytes,
        "within_budget": total_bytes <= MAX_BYTES,
        "video_count": len(rows),
        "video_bytes": sum(row["size_bytes"] for row in rows),
        "videos": rows,
    }
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if report["within_budget"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
