#!/usr/bin/env python3
"""Strictly audit one LIBERO-Dynamic result group without loading traces in memory."""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
from typing import Any, Iterable


EXPECTED_SPEEDS = ("003", "006", "009")
EXPECTED_PER_SPEED = 600
EXPECTED_TOTAL = 1800


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                value = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in {path}:{line_number}: {exc}") from exc
            if isinstance(value, dict):
                yield value


def manifest_rows(root: Path) -> Iterable[tuple[Path, dict[str, Any]]]:
    for path in sorted(root.rglob("manifests/*.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(value, dict):
            yield path, value
    for path in sorted(root.rglob("*manifest*.jsonl")):
        for row in iter_jsonl(path):
            yield path, row


def speed_label(row: dict[str, Any], source: Path) -> str | None:
    for value in (row.get("speed"), row.get("speed_mps"), row.get("object_speed")):
        if value is None:
            continue
        text = str(value).lower().replace("speed_", "")
        if text in EXPECTED_SPEEDS:
            return text
        try:
            number = float(text)
        except ValueError:
            continue
        label = f"{round(number * 100):03d}"
        if label in EXPECTED_SPEEDS:
            return label
    match = re.search(r"speed_(003|006|009)", str(source))
    return None if match is None else match.group(1)


def trace_value(row: dict[str, Any]) -> str | None:
    for key in ("step_trace", "step_trace_path", "trace", "trace_path"):
        value = row.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def resolve_trace(value: str | None, manifest: Path, search_root: Path | None) -> Path | None:
    if not value:
        return None
    path = Path(value).expanduser()
    candidates = [path]
    if not path.is_absolute():
        candidates.append(manifest.parent / path)
        if len(manifest.parents) > 3:
            candidates.append(manifest.parents[3] / path)
    for candidate in candidates:
        if candidate.is_file() and candidate.stat().st_size > 0:
            return candidate.resolve()
    if search_root is not None:
        matches = list(search_root.rglob(path.name))
        valid = [item for item in matches if item.is_file() and item.stat().st_size > 0]
        if len(valid) == 1:
            return valid[0].resolve()
    return None


def validate_trace(path: Path, required_fields: set[str]) -> tuple[bool, str | None]:
    """Stream-validate a trace and optionally require fields to appear."""
    rows = 0
    seen_fields: set[str] = set()
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                if not line.strip():
                    continue
                value = json.loads(line)
                if not isinstance(value, dict):
                    return False, f"line {line_number} is not a JSON object"
                rows += 1
                seen_fields.update(value)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        return False, str(exc)
    if rows == 0:
        return False, "trace contains no records"
    missing = sorted(required_fields - seen_fields)
    if missing:
        return False, f"required fields never appear: {missing}"
    return True, None


def stable_projection(row: dict[str, Any]) -> str:
    projection = {
        key: row.get(key)
        for key in ("item_id", "status", "error", "success", "steps", "calibrated_latency_seconds")
    }
    return json.dumps(projection, sort_keys=True, default=str)


def audit(
    root: Path,
    require_traces: bool,
    trace_search_root: Path | None,
    required_trace_fields: set[str],
) -> dict[str, Any]:
    selected: dict[tuple[str, str], tuple[Path, dict[str, Any]]] = {}
    duplicate_same = 0
    duplicate_conflicts: list[dict[str, str]] = []
    for source, row in manifest_rows(root):
        item_id = row.get("item_id")
        speed = speed_label(row, source)
        if not item_id or speed is None:
            continue
        key = (speed, str(item_id))
        if key not in selected:
            selected[key] = (source, row)
            continue
        previous_source, previous = selected[key]
        if stable_projection(previous) == stable_projection(row):
            duplicate_same += 1
            if trace_value(previous) is None and trace_value(row) is not None:
                selected[key] = (source, row)
        else:
            duplicate_conflicts.append(
                {"key": f"{speed}:{item_id}", "first": str(previous_source), "second": str(source)}
            )

    speed_counts = Counter(speed for speed, _item_id in selected)
    status_ok = 0
    errors = 0
    successes = 0
    diagnostics_ok = 0
    traces = 0
    missing_traces: list[str] = []
    damaged_traces: list[dict[str, str]] = []
    protocol_violations: list[dict[str, str]] = []
    for (speed, item_id), (source, row) in selected.items():
        status_ok += int(row.get("status") == "ok")
        errors += int(bool(row.get("error")) or row.get("status") not in {None, "ok"})
        successes += int(bool(row.get("success")))
        diagnostics = row.get("diagnostics")
        diagnostic_value = row.get("diagnostics_ok")
        if isinstance(diagnostics, dict):
            diagnostic_value = diagnostics.get("ok", diagnostic_value)
        diagnostics_ok += int(bool(diagnostic_value))
        controller = row.get("controller_summary")
        if not isinstance(controller, dict):
            protocol_violations.append({"key": f"{speed}:{item_id}", "reason": "missing controller_summary"})
            controller = {}
        if row.get("stop_on_success") is not True:
            protocol_violations.append({"key": f"{speed}:{item_id}", "reason": "stop_on_success is not true"})
        if row.get("speed") is None:
            protocol_violations.append({"key": f"{speed}:{item_id}", "reason": "missing manifest speed"})
        if row.get("policy") == "openpi_ws" and not isinstance(row.get("policy_server_metadata"), dict):
            protocol_violations.append({"key": f"{speed}:{item_id}", "reason": "missing policy_server_metadata"})
        if row.get("control_mode") == "rtc_queue" and controller.get("rtc_conditioning_used") is not True:
            protocol_violations.append({"key": f"{speed}:{item_id}", "reason": "RTC conditioning was not actually used"})
        try:
            k = int(row["replan_steps_requested"])
            theta = row.get("chunk_size_threshold")
            expected_threshold = (
                int(row.get("prefetch_threshold", 0))
                if theta is None
                else int(math.ceil(float(theta) * k))
            )
            actual_threshold = int(controller["effective_prefetch_threshold_steps"])
            if actual_threshold != expected_threshold:
                protocol_violations.append(
                    {
                        "key": f"{speed}:{item_id}",
                        "reason": (
                            "effective prefetch threshold mismatch: "
                            f"expected {expected_threshold}, found {actual_threshold}"
                        ),
                    }
                )
        except (KeyError, TypeError, ValueError):
            protocol_violations.append(
                {"key": f"{speed}:{item_id}", "reason": "missing K/prefetch audit fields"}
            )
        resolved = resolve_trace(trace_value(row), source, trace_search_root)
        if resolved is None:
            if require_traces:
                missing_traces.append(f"{speed}:{item_id}")
        else:
            valid, reason = validate_trace(resolved, required_trace_fields)
            if valid:
                traces += 1
            elif require_traces:
                damaged_traces.append(
                    {"key": f"{speed}:{item_id}", "path": str(resolved), "reason": str(reason)}
                )

    issues: list[str] = []
    if len(selected) != EXPECTED_TOTAL:
        issues.append(f"expected {EXPECTED_TOTAL} unique rows, found {len(selected)}")
    for speed in EXPECTED_SPEEDS:
        if speed_counts[speed] != EXPECTED_PER_SPEED:
            issues.append(f"speed {speed}: expected {EXPECTED_PER_SPEED}, found {speed_counts[speed]}")
    if status_ok != EXPECTED_TOTAL:
        issues.append(f"expected {EXPECTED_TOTAL} status=ok rows, found {status_ok}")
    if errors:
        issues.append(f"found {errors} error/non-ok rows")
    if duplicate_conflicts:
        issues.append(f"found {len(duplicate_conflicts)} conflicting duplicate keys")
    if protocol_violations:
        issues.append(f"found {len(protocol_violations)} protocol violations")
    if require_traces and traces != EXPECTED_TOTAL:
        issues.append(
            f"expected {EXPECTED_TOTAL} valid traces, found {traces} "
            f"({len(missing_traces)} missing, {len(damaged_traces)} damaged)"
        )
    digest = hashlib.sha256()
    for key in sorted(selected):
        digest.update(f"{key[0]}\0{key[1]}\0{stable_projection(selected[key][1])}\n".encode())
    return {
        "schema_version": 1,
        "root": str(root.resolve()),
        "complete": not issues,
        "episodes": len(selected),
        "successes": successes,
        "success_rate": successes / EXPECTED_TOTAL if len(selected) == EXPECTED_TOTAL else None,
        "diagnostics_ok": diagnostics_ok,
        "status_ok": status_ok,
        "errors": errors,
        "trace_count": traces,
        "speed_counts": dict(sorted(speed_counts.items())),
        "identical_duplicate_rows_ignored": duplicate_same,
        "duplicate_conflicts": duplicate_conflicts[:50],
        "missing_trace_keys": missing_traces[:50],
        "damaged_traces": damaged_traces[:50],
        "protocol_violations": protocol_violations[:50],
        "required_trace_fields": sorted(required_trace_fields),
        "row_projection_sha256": digest.hexdigest(),
        "issues": issues,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("--require-traces", action="store_true")
    parser.add_argument("--trace-search-root", type=Path, default=None)
    parser.add_argument(
        "--required-trace-field",
        action="append",
        default=[],
        help="Field that must appear at least once in every streamed trace; repeat as needed.",
    )
    parser.add_argument("--output", type=Path, default=None)
    args = parser.parse_args()
    report = audit(
        args.root.expanduser().resolve(),
        require_traces=args.require_traces,
        trace_search_root=None if args.trace_search_root is None else args.trace_search_root.resolve(),
        required_trace_fields=set(args.required_trace_field),
    )
    rendered = json.dumps(report, indent=2) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if report["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
