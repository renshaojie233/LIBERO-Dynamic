#!/usr/bin/env python3
"""Dependency-light regression tests for the released scheduling protocol."""

from __future__ import annotations

from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"
if not CODE.is_dir():
    CODE = ROOT.parents[1] / "scripts"
sys.path.insert(0, str(CODE))

from realtime_eval.control import ActionChunkPacket, ActionRuntime, LatencySampler, ObservationPacket
from realtime_eval.strategies.async_queue import AsyncQueueController
from realtime_eval.strategies.rtc_queue import RtcQueueController
from realtime_eval.strategies.sync_hold import SyncHoldController


class Policy:
    def get_action_chunk(self, obs, language):
        del obs, language
        return np.zeros((10, 7), dtype=np.float32)


class RtcPolicy(Policy):
    supports_rtc_conditioning = True

    def get_action_chunk_rtc(
        self,
        obs,
        language,
        *,
        prev_chunk_left_over,
        inference_delay_steps,
    ):
        del obs, language, prev_chunk_left_over, inference_delay_steps
        return np.zeros((10, 7), dtype=np.float32)


def packet(step: int = 0) -> ObservationPacket:
    return ObservationPacket(
        episode_id="test",
        step_idx=step,
        sim_time_s=step / 20.0,
        language="test",
        obs={},
        queue_len=0,
        last_action=np.zeros(7, dtype=np.float32),
    )


def controller(cls, *, latency: float = 0.0, theta: float | None = None, policy=None):
    return cls(
        policy=policy or Policy(),
        language="test",
        control_freq=20,
        mode="rtc_queue" if cls is RtcQueueController else (
            "sync_hold" if cls is SyncHoldController else "async_queue"
        ),
        prefetch_threshold=0,
        action_chunk_size=10,
        chunk_size_threshold=theta,
        latency_sampler=LatencySampler(source="fixed", fixed_seconds=latency),
    )


class RuntimeProtocolTests(unittest.TestCase):
    def test_threshold_uses_ceiling_without_latency_inflation(self) -> None:
        ctl = controller(AsyncQueueController, latency=0.2, theta=0.1)
        try:
            self.assertEqual(ctl.effective_prefetch_threshold_steps(), 1)
            self.assertEqual(ctl.latency_budget_steps(), 4)
        finally:
            ctl.close()

    def test_zero_latency_async_is_available_in_same_tick(self) -> None:
        ctl = controller(AsyncQueueController)
        actions = ActionRuntime(7)
        try:
            ready = ctl.tick(packet(), actions)
            self.assertEqual(len(ready), 1)
            self.assertEqual(ready[0].available_step_idx, 0)
            self.assertGreater(actions.queue_len, 0)
        finally:
            ctl.close()

    def test_sync_latency_is_continuous_not_queue_ticks(self) -> None:
        ctl = controller(SyncHoldController, latency=0.075)
        actions = ActionRuntime(7)
        try:
            ready = ctl.tick(packet(), actions)
            self.assertEqual(len(ready), 1)
            self.assertEqual(ready[0].metadata["delay_steps"], 0)
            self.assertEqual(ready[0].metadata["latency_application"], "continuous_physics")
            self.assertAlmostEqual(ready[0].metadata["sim_latency_s"], 0.075)
        finally:
            ctl.close()

    def test_rtc_metadata_cannot_claim_conditioning_on_plain_policy(self) -> None:
        ctl = controller(RtcQueueController, policy=Policy())
        actions = ActionRuntime(7)
        try:
            ready = ctl.tick(packet(), actions)
            self.assertFalse(ready[0].metadata["rtc_conditioning_used"])
            self.assertFalse(ctl.summary()["rtc_conditioning_used"])
        finally:
            ctl.close()

    def test_rtc_metadata_records_real_conditioning(self) -> None:
        ctl = controller(RtcQueueController, policy=RtcPolicy())
        actions = ActionRuntime(7)
        try:
            ready = ctl.tick(packet(), actions)
            self.assertTrue(ready[0].metadata["rtc_conditioning_used"])
            self.assertTrue(ctl.summary()["rtc_conditioning_used"])
        finally:
            ctl.close()

    def test_underflow_holds_do_not_age_async_chunk(self) -> None:
        actions = ActionRuntime(2, empty_action="hold")
        for _ in range(3):
            actions.next_action()
        stats = actions.merge_weighted(
            ActionChunkPacket(
                episode_id="test",
                chunk_id=1,
                obs_step_idx=0,
                submit_step_idx=0,
                available_step_idx=3,
                policy_elapsed_s=0.15,
                actions=np.asarray([[1, 1], [2, 2], [3, 3]], dtype=np.float32),
                controller="async_queue",
                metadata={"executed_queue_actions_since_submit": 0},
            )
        )
        self.assertEqual(stats["dropped_prefix"], 0)
        self.assertEqual(actions.queue_len, 3)


if __name__ == "__main__":
    unittest.main(verbosity=2)
