#!/usr/bin/env python3
"""Reject common identity, infrastructure, and credential leaks."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import re


TEXT_SUFFIXES = {
    ".csv", ".json", ".md", ".py", ".sh", ".toml", ".txt", ".yaml", ".yml"
}
RULES = {
    "private filesystem path": re.compile(r"/(?:home|mnt|Users|private|var/folders)/", re.I),
    "SSH material": re.compile(r"(?:BEGIN [A-Z ]*PRIVATE KEY|IdentityFile|\.ssh/)", re.I),
    "non-loopback IPv4 address": re.compile(
        r"\b(?!(?:127\.0\.0\.1|0\.0\.0\.0)\b)(?:\d{1,3}\.){3}\d{1,3}\b"
    ),
}


def scan(root: Path, deny_tokens: list[str]) -> list[dict[str, object]]:
    findings: list[dict[str, object]] = []
    scanner_path = Path(__file__).resolve()
    rules = dict(RULES)
    for index, token in enumerate(deny_tokens):
        if token:
            rules[f"caller-supplied deny token {index + 1}"] = re.compile(
                re.escape(token), re.I
            )
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        relative = path.relative_to(root)
        if relative.parts and relative.parts[0] == "dist":
            continue
        # The scanner necessarily contains the forbidden-pattern definitions.
        if path.resolve() == scanner_path:
            continue
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            continue
        for line_number, line in enumerate(lines, 1):
            for rule, pattern in rules.items():
                if pattern.search(line):
                    findings.append(
                        {
                            "file": str(relative),
                            "line": line_number,
                            "rule": rule,
                            "text": line.strip()[:180],
                        }
                    )
    return findings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path, nargs="?", default=Path(__file__).resolve().parents[1])
    parser.add_argument(
        "--deny-token",
        action="append",
        default=[],
        help="Additional private identifier to reject; repeat without committing the value.",
    )
    args = parser.parse_args()
    root = args.root.expanduser().resolve()
    environment_tokens = [
        token.strip()
        for token in os.environ.get("DOUBLE_BLIND_DENY_TOKENS", "").split(",")
        if token.strip()
    ]
    findings = scan(root, [*args.deny_token, *environment_tokens])
    if findings:
        for finding in findings:
            print(
                f"{finding['file']}:{finding['line']}: {finding['rule']}: {finding['text']}"
            )
        return 1
    print(f"Double-blind scan passed: {root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
