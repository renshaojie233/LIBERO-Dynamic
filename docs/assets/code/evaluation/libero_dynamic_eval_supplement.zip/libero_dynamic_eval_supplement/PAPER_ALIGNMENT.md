# Paper Alignment and Result Provenance

This document is the checklist for keeping the manuscript, figures, tables, and
released evaluation code on the same protocol. All rates below are measured
over complete 1,800-episode groups with zero errors.

## Original-model asynchronous comparison

Use `tables/original_models_async.csv`. Each model contributes its best complete
point from its own asynchronous K sweep; Sync and RTC are not mixed into this
comparison.

| Model | K | Frozen latency (ms) | Successes |
|---|---:|---:|---:|
| Pi0.5 JAX | 4 | 60.294 | 1,041/1,800 |
| Pi0 JAX | 8 | 57.029 | 567/1,800 |
| VLA-JEPA | 4 | 55.897 | 643/1,800 |
| OpenVLA-OFT | 4 | 92.611 | 491/1,800 |
| FastWAM-Joint | 8 | 64.394 | 731/1,800 |
| FastWAM | 7 | 62.831 | 584/1,800 |

The Pi0.5 value here is 1,041/1,800. The alternate 1,075/1,800 run belongs to a
different historical run root whose protocol difference has not been reconciled;
it must not appear beside this table as if it were the same measurement.

## Pi0.5 PyTorch execution methods

Use `tables/pi05_execution_strategies.csv` for the complete sweep. The paper's
current radar selection is:

| Method | Protocol | K | Frozen latency (ms) | Successes |
|---|---|---:|---:|---:|
| Sync | world-continuing `sync_hold` | 7 | 147.199 | 761/1,800 |
| Async | queue ratio 0.5, weighted overlap | 6 | 147.199 | 871/1,800 |
| RTC | fixed ten remaining actions | 16 | 169.802 | 681/1,800 |
| VLASH | causal continuous-world adaptation | 5 | 103.987 | 1,026/1,800 |

RTC with a proportional 0.5 request threshold and RTC with a fixed ten-action
threshold are separate protocols. The historical VLASH delayed-image/current-
state shortcut is ineligible for the continuous-world comparison.

## Zero-latency synchronous ablation

Use `tables/pi05_sync_zero_latency.csv`. This is an idealized ablation with
frozen latency exactly zero, not the deployment-latency Sync baseline. K=1--16
listed in that file have complete manifests and traces. Historical K=32 and K=50
aggregate counts are excluded because the strict bundle does not contain their
complete trace-level artifacts.

## Dynamic fine-tuning comparisons

Use `tables/dynamic_finetuning.csv`. Every pair is matched by controller, K, and
frozen latency.

| Architecture | K | Base | Dynamic FT |
|---|---:|---:|---:|
| Pi0.5 | 4 | 1,041/1,800 | 1,248/1,800 |
| Single-frame Joint | 4 | 727/1,800 | 889/1,800 |
| History-frame Joint | 8 | 788/1,800 | 1,203/1,800 |

The history-frame bar uses K=8 for both base and fine-tuned models. The older
K=10 history-frame result is a different operating point and must not replace
the matched K=8 comparison.

## Latency calibration audit

The frozen latencies above are linked to `tables/latency_calibrations.csv` by
`latency_calibration_id` in `configs/paper_experiments.json`. Warm-up requests
are discarded; retained requests are the samples used to compute the reported
median. Counts below were read from the original calibration records rather
than reconstructed from defaults.

| Calibration | Runs | Warm-up / run | Warm-up total | Retained / run | Retained total |
|---|---:|---:|---:|---:|---:|
| Pi0.5 JAX | 1 | 8 | 8 | 88 | 88 |
| Pi0 JAX | 2 | 8 | 16 | 88 | 176 |
| VLA-JEPA | 2 | 30 | 60 | 300 | 600 |
| OpenVLA-OFT | 2 | 8 | 16 | 88 | 176 |
| FastWAM-Joint / single-frame Joint | 1 | 20 | 20 | 100 | 100 |
| FastWAM | 1 | 8 | 8 | 88 | 88 |
| Pi0.5 PyTorch Sync / Async | 1 | 8 | 8 | 88 | 88 |
| Pi0.5 PyTorch RTC | 1 | 8 | 8 | 88 | 88 |
| VLASH continuous | 2 | 8 | 16 | 88 | 176 |
| History-frame Joint | 1 | 20 | 20 | 100 | 100 |

Pi0.5 Dynamic FT inherits the Pi0.5 JAX calibration; single-frame Joint
Dynamic FT inherits the FastWAM-Joint calibration; base and Dynamic-FT
history-frame Joint share the history-frame calibration. The zero-latency Sync
ablation is intentionally excluded from the measured-calibration counts. The
history-frame source retains an exact frozen summary with explicit counts,
whereas the other rows retain request-level samples (and, for VLA-JEPA,
request-level samples grouped into rounds).

## Reporting rules

- Report task success independently of `diagnostics.ok` and trace validity.
- State whether latency is frozen deployment latency, measured wall-clock
  latency, pure model inference, or zero-latency ablation.
- Never combine incomplete groups, estimates, or aggregate-only rows with the
  strict 1,800-episode results.
- Preserve K, controller, threshold rule, checkpoint family, inference steps,
  and native horizon in every table or figure source.
- Preserve `latency_calibration_id`, warm-up count, retained-sample count, and
  evidence granularity for every nonzero frozen latency.
- The radar charts are descriptive profiles, not scalar rankings.

Measurements intentionally contain no host names, local paths, user names,
private repository identifiers, or checkpoint fingerprints.

## Representative appendix gallery

The appendix gallery is descriptive benchmark material, not an additional
model evaluation. It selects one task from each ten-task subset and shows all
three motion families at the fixed 0.09 m/s speed. Selection is independent of
policy outcomes. The exact task IDs, trajectory variants, phases, released
video hashes, and extracted-frame hashes are recorded under `task_gallery/`.

Recommended layout: four rows (Spatial, Object, Goal, Long-horizon) by three
columns (Linear, Curvilinear, Zigzag). Each cell should use the corresponding
eight-frame contact sheet. The short dual-view MP4 and individual agent-view
stills remain available in the electronic supplement.

The electronic supplement additionally includes `full_video_gallery/`: one
uniform 256x256 agent-view clip for every one of the 40 tasks under Linear,
Curvilinear, and Zigzag motion at 0.09 m/s (120 clips). Filenames expose the
global task ID, subset, concise task label, motion family, and speed. Its
manifest records exact task text, trajectory, phase, source item, release
checks, media metadata, and SHA-256. This full gallery is for coverage and
inspection; the compact 12-cell layout remains the recommended printed figure.
